
11/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB1790375598620"�
app/build.gradleB/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/app/build.gradle� ���Ս4*@4f4baf0f34e15f61f9dd6857573273d0360001982bb2cef1809a28dba4afad45"�
build.gradle>/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/build.gradle� ���ύ4*@5a1842bab4090343acc5124d17604266928789f4bd2fd99cd171c7d73af9f95d"�
(gradle/wrapper/gradle-wrapper.propertiesZ/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/gradle/wrapper/gradle-wrapper.properties� �儃�4*@1cead55aa2827f7941144fef9db50c615578702e38b44e6a956ef1809f401112"�
gradle.propertiesC/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/gradle.properties� ���ύ4*@5b6fa4fbbf3fdd8464a17709e935fc8e67891f9825c4c3996547893c4b4b17fa"�
settings.gradleA/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/settings.gradle� ���ύ4*@7e46d8baecd0a36688f2a9fce93481c5dedda48410e04db4e480bfb4ab161c36*�
L/storage/emulated/0/AndroidIDEProjects/MeuXboxUSB/.cg/gradle-sync/project.pb@992366566c3c56f38864708072a835358cc42f9eb4891e57112ee54e91f51ca5