# MeuXbox USB — documentação técnica e continuidade

**Versão analisada:** pacote `MeuXboxUSB_8.0.zip`  
**Pacote Android:** `mhs.usb.meuxbox`  
**Versão declarada no Gradle:** `versionName "0.8.0"`, `versionCode 9`  
**Linguagem:** Java  
**Tipo de projeto:** Android nativo, Gradle, módulo único `app`

> Este documento foi elaborado a partir do código e dos recursos presentes no ZIP. O arquivo contém um projeto Gradle Android funcional em estrutura; não há metadados específicos do Code On The Go no pacote, portanto as responsabilidades abaixo foram inferidas diretamente das classes, layouts e configurações recebidos.

## 1. Objetivo do aplicativo

O **MeuXbox USB** é um aplicativo para Android voltado a consoles Xbox 360 modificados (RGH/JTAG). Ele permite conectar um pendrive ou HD via USB OTG, copiar jogos do armazenamento do celular para o dispositivo USB e administrar o conteúdo já instalado.

As funções principais são:

- detectar e conectar um armazenamento USB;
- copiar jogos nos formatos **GOD/STFS**, **XEX** e arquivos avulsos;
- identificar o **Title ID** por meio do `default.xex` ou da estrutura STFS;
- escolher automaticamente destinos como `Content/0000000000000000/<TitleID>/`, `Games/` ou `Apps/`;
- manter a cópia em um serviço em primeiro plano, com notificação e progresso;
- tentar novamente cópias que falham;
- listar jogos, DLCs, saves e updates presentes no USB;
- mostrar nomes e capas quando houver dados locais ou acesso à internet;
- excluir jogos/conteúdos e calcular tamanhos;
- oferecer um gerenciador de arquivos USB e backup para o armazenamento do celular;
- exibir um tutorial local, que funciona offline;
- oferecer uma tela de diagnóstico USB somente leitura.

## 2. Arquitetura resumida

```mermaid
flowchart TD
    A[MainActivity\nTela principal] --> B[UsbXboxConnection\nConexão USB compartilhada]
    A --> C[TransferService\nCópia de jogos e arquivos]
    A --> D[MeusJogosFragment\nCatálogo instalado]
    A --> E[FileManagerActivity\nGerenciador de arquivos]
    A --> F[TutorialWebActivity\nTutorial local]
    A --> G[UsbDiagActivity\nDiagnóstico somente leitura]
    D --> B
    D --> H[GameAdapter]
    D --> I[XexParser / StfsParser]
    E --> B
    E --> J[FileManagerService\nCopiar/colar e backup]
    C --> B
    C --> I
    H --> K[GameDatabase\njogos.csv]
    H --> L[Capas online\nXboxUnity/Archive.org]
```

### Fluxo de envio de um jogo

1. `MainActivity` solicita acesso ao USB e mantém a conexão em `UsbXboxConnection`.
2. O usuário seleciona a pasta local pelo **Storage Access Framework** (`DocumentFile`).
3. `MainActivity` procura `default.xex` e/ou identifica a estrutura do jogo.
4. `XexParser` extrai o Title ID quando o jogo é XEX.
5. Para XEX, o usuário escolhe `Games/` ou `Apps/`; para GOD/STFS, o destino é montado sob `Content/0000000000000000/<TitleID>/`.
6. `TransferService` cria as tarefas, copia os arquivos em segundo plano, atualiza a notificação e informa o progresso à tela.
7. Ao terminar, a UI mostra sucesso, falhas ou uma mensagem para reconectar o USB.

### Fluxo do catálogo

1. `MeusJogosFragment` conecta automaticamente ao primeiro dispositivo USB de armazenamento encontrado.
2. O fragmento percorre `Content/0000000000000000` para jogos GOD/STFS e `Games/`/`Apps/` para XEX.
3. `XexParser` identifica Title IDs em `default.xex`; a estrutura de pastas fornece IDs nos jogos GOD.
4. Os tipos `00000001`, `00000002` e `000B0000` são tratados como save, DLC e update.
5. `GameDatabase` tenta converter Title ID em nome usando `assets/jogos.csv`.
6. `GameAdapter` exibe a grade, carrega capas e permite ver extras ou excluir conteúdo.

## 3. Estrutura de diretórios

```text
MeuXboxUSB/
├── build.gradle                 # Plugins Android compartilhados
├── settings.gradle              # Nome do projeto, repositórios e módulo app
├── gradle.properties            # Opções do Gradle e AndroidX
├── gradlew / gradlew.bat        # Wrapper para executar o Gradle
├── gradle/wrapper/              # Configuração do Gradle Wrapper 8.13
├── release.properties           # Arquivo auxiliar de assinatura; contém segredo
├── app/
│   ├── build.gradle             # Configuração do aplicativo e dependências
│   ├── proguard-rules.pro       # Regras de redução/obfuscação do release
│   └── src/main/
│       ├── AndroidManifest.xml  # Permissões, activities e services
│       ├── java/mhs/usb/meuxbox/# Código Java
│       ├── res/                 # Layouts, strings, temas, ícones e áudio
│       ├── assets/              # CSV e tutorial offline
│       └── play_store_512.png   # Ícone de 512 px para publicação
```

Os diretórios `.gradle/`, `build/` e `.cg/` são artefatos/estado de ferramentas e não fazem parte da lógica do aplicativo. Em um repositório Git, devem permanecer ignorados ou ser removidos do pacote de distribuição.

## 4. Arquivos Java e responsabilidades

Todos os arquivos abaixo estão em `app/src/main/java/mhs/usb/meuxbox/`.

### 4.1 Telas e navegação

| Arquivo | Responsabilidade |
|---|---|
| `MainActivity.java` | Tela principal. Controla seleção do destino USB, seleção de pastas/arquivos locais, detecção XEX/GOD, escolha do destino XEX, início da transferência, progresso, sons, tutorial, créditos e abertura das demais telas. Usa `DocumentFile` para ler o armazenamento local escolhido pelo usuário. |
| `MeusJogosFragment.java` | Tela/fragmento do catálogo. Conecta ao USB, varre jogos principais e extras, calcula tamanhos, filtra DLC/saves/updates por Title ID e dispara exclusões. |
| `FileManagerActivity.java` | Gerenciador de arquivos do USB. Navega por pastas, mantém breadcrumbs, mostra capacidade/uso/livre, permite seleção múltipla, copiar, colar, excluir e iniciar backup para o celular. |
| `TutorialWebActivity.java` | Abre `file:///android_asset/tutorial/index.html` em uma `WebView`. Ativa JavaScript apenas para o seletor de idioma e passa o tema claro pela query string. |
| `UsbDiagActivity.java` | Diagnóstico avançado. Lista dispositivos USB, solicita permissão, inicializa partições e lê os primeiros 512 bytes para procurar a assinatura `FATX`. É destinado a diagnóstico e não deveria escrever no dispositivo. |

### 4.2 USB, cópia e serviços

| Arquivo | Responsabilidade |
|---|---|
| `UsbXboxConnection.java` | Singleton que mantém a conexão ativa com `UsbMassStorageDevice`, sua partição e `FileSystem` da libaums. Faz detecção automática, pede permissão Android, tenta inicialização até três vezes, resolve caminhos e exclui recursivamente. |
| `TransferService.java` | Serviço em primeiro plano para envio de jogos/arquivos. Mapeia tarefas XEX/STFS, cria diretórios de destino, copia em blocos de 64 KiB, usa até três tentativas por arquivo, mantém `WakeLock`, notificação e progresso. Também pula arquivos que já correspondem ao tamanho esperado quando aplicável. |
| `FileManagerService.java` | Serviço em primeiro plano para operações genéricas do gerenciador: copiar/colar dentro do USB e backup USB → armazenamento Android via SAF. Usa progresso, notificação, `WakeLock`, buffer de 64 KiB e tentativas. |

### 4.3 Catálogo, modelos e apresentação

| Arquivo | Responsabilidade |
|---|---|
| `ListarGames.java` | Modelo de um jogo ou extra. Guarda Title ID, nome, URL da capa, caminho no USB, tipo de conteúdo, flag de extra e tamanho. `isFormatoGod()` identifica caminhos iniciados por `Content/`. |
| `GameAdapter.java` | Adapter da grade de jogos. Renderiza itens, detalhes, tamanho total, extras, desinstalação e capas. Usa executor com quatro threads, `LruCache` de bitmaps e atualização na thread principal. |
| `GameDatabase.java` | Carrega `assets/jogos.csv` uma vez e mapeia Title ID para nome. Se não encontrar, mostra o ID. |
| `FileManagerAdapter.java` | Adapter da lista do gerenciador de arquivos. Diferencia pastas/arquivos, mostra tamanhos, permite toque longo e seleção múltipla e dá rótulo legível às pastas de Title ID. |
| `ScreenUtils.java` | Calcula largura mínima em dp, quantidade de colunas da grade, largura de diálogos e comportamento para telas de tablet. |
| `ThemeManager.java` | Persiste/restaura preferência de tema claro/escuro e aplica o tema antes da renderização das telas. |

### 4.4 Parsers de formatos Xbox

| Arquivo | Responsabilidade |
|---|---|
| `XexParser.java` | Lê `default.xex` local via `DocumentFile` ou no USB via `UsbFile`. Valida a assinatura `XEX2`, localiza o header de execução e extrai o Title ID em hexadecimal. |
| `StfsParser.java` | Lê cabeçalhos STFS `CON `, `LIVE` ou `PIRS`. Obtém `profileId` e o primeiro nome de exibição UTF-16BE disponível, sem interromper o escaneamento quando um pacote está inválido. |

## 5. Manifesto e permissões

`app/src/main/AndroidManifest.xml` declara:

- `INTERNET` e `ACCESS_NETWORK_STATE`: capas/ícones online e verificação de rede;
- `FOREGROUND_SERVICE` e `FOREGROUND_SERVICE_DATA_SYNC`: cópias longas em primeiro plano;
- `POST_NOTIFICATIONS`: notificações de progresso em Android recente;
- `WAKE_LOCK`: manter a CPU ativa durante cópias;
- `android.hardware.usb.host`: indica suporte USB Host como recurso opcional;
- `MainActivity`: launcher/exportada;
- `UsbDiagActivity`, `FileManagerActivity` e `TutorialWebActivity`: telas internas;
- `TransferService` e `FileManagerService`: serviços internos com tipo `dataSync`.

O projeto usa o broadcast interno `mhs.usb.meuxbox.USB_PERMISSION` para o fluxo de permissão do `UsbManager`.

## 6. Recursos XML, assets e sons

### Layouts

- `activity_main.xml`: tela principal; há versões alternativas em `layout-sw905dp/` para telas largas.
- `fragment_meus_jogos.xml`: catálogo; há versão em `layout-sw600dp/`.
- `activity_file_manager.xml`: gerenciador; há versão em `layout-sw600dp/`.
- `activity_tutorial_web.xml`: WebView e progresso do tutorial.
- `item_game.xml`: cartão individual de jogo.
- `item_file_manager.xml`: item de arquivo/pasta.
- `dialog_detalhes.xml`: detalhes, tamanho, Title ID, extras e desinstalação.
- `dialog_info_creditos.xml`: créditos.
- `dialog_tutorial.xml`: instruções rápidas iniciais.

### Drawables e tema

- `bg_button_primary.xml`, `bg_button_secondary.xml`, `bg_input_field.xml`: fundos visuais.
- `ic_folder.xml`, `ic_gamepad.xml`, `ic_info.xml`, `ic_network.xml`: ícones vetoriais.
- `ic_launcher*`: ícone adaptativo e variações por densidade.
- `values/colors.xml`, `values-night/colors.xml`: cores claro/escuro.
- `values/themes.xml`: tema Material/AppCompat.
- `values/strings.xml`, `values-pt-rBR/strings.xml` e demais `values-*/strings.xml`: textos e traduções.
- `xml/backup_rules.xml` e `xml/data_extraction_rules.xml`: regras de backup do Android.

### Assets

- `assets/jogos.csv`: tabela `Title ID,nome`; usada por `GameDatabase`.
- `assets/tutorial/index.html`: tutorial offline em português, inglês, espanhol e francês, com seletor de idioma, tema claro/escuro e imagens locais.
- `assets/tutorial/*.png`/`*.jpg`: capturas e ilustrações do tutorial.

### Áudio

- `res/raw/sucesso.mp3`: sinal de sucesso.
- `res/raw/erro.mp3`: sinal de erro.

## 7. Gradle e dependências

### `app/build.gradle`

- Plugin `com.android.application`.
- `namespace` e `applicationId`: `mhs.usb.meuxbox`.
- `compileSdk 36`, `targetSdk 36`, `minSdk 24`.
- Java 17 (`sourceCompatibility` e `targetCompatibility`).
- `viewBinding true`.
- Release com `minifyEnabled true` e regras padrão + `proguard-rules.pro`.

Dependências principais:

- `androidx.appcompat:appcompat:1.6.1`: compatibilidade de activities e tema;
- `com.google.android.material:material:1.9.0`: componentes Material;
- `androidx.constraintlayout:constraintlayout:2.1.4`: layouts;
- `androidx.documentfile:documentfile:1.0.1`: acesso SAF;
- `androidx.recyclerview:recyclerview:1.3.0`: listas e grades;
- `androidx.cardview:cardview:1.0.0`: cartões;
- `me.jahnen.libaums:core:0.10.0`: acesso a USB Mass Storage por baixo nível.

O bloco `resolutionStrategy` força as variantes do Kotlin stdlib em `1.8.0` para evitar classes duplicadas trazidas pela libaums. Se atualizar a libaums ou outras bibliotecas, revisar essa regra.

### Arquivos de configuração

- `build.gradle`: versões dos plugins Android (`8.11.0`) e tarefa `clean`.
- `settings.gradle`: repositórios Google/Maven Central, nome `MeuXbox USB` e inclusão de `:app`.
- `gradle.properties`: AndroidX, namespace transitive, codificação UTF-8 e memória do Gradle.
- `gradle/wrapper/gradle-wrapper.properties`: Gradle Wrapper `8.13`.

## 8. Como dar continuidade ao desenvolvimento

1. Trabalhe sempre a partir da raiz que contém `settings.gradle`.
2. Antes de editar, identifique se a alteração é de UI (`res/layout`), texto (`res/values`), regra de negócio (Java) ou dependência (Gradle).
3. Operações de I/O USB não devem ser executadas na thread da UI. Preserve os padrões existentes: `Thread`/executor, callback na UI e tratamento de desconexão.
4. Nunca altere caminhos Xbox sem testar tanto GOD/STFS quanto XEX.
5. Ao alterar `Title ID`, valide pelo menos um `default.xex` real e uma pasta GOD real.
6. Ao alterar serviços, teste minimizar o app, bloquear a tela, desconectar/reconectar o cabo e observar a notificação.
7. Ao alterar o catálogo, teste jogo principal, DLC (`00000002`), save (`00000001`) e update (`000B0000`).
8. Ao alterar strings, atualize `values/strings.xml` e avalie as traduções existentes.
9. O botão de exclusão é destrutivo e sem lixeira; preserve a confirmação antes de chamar `UsbXboxConnection.deletarRecursivo()`.
10. Não coloque chaves, senhas ou keystores no Git.

## 9. Conversão/abertura no Android Studio

Este pacote **já é um projeto Gradle Android**. Em geral, não é necessário criar outro projeto nem copiar classes manualmente.

### Pré-requisitos

- Android Studio atualizado que suporte Android Gradle Plugin `8.11.0` e Gradle `8.13`;
- JDK 17 configurado no Android Studio;
- Android SDK Platform 36;
- Android SDK Build-Tools compatível;
- um celular Android com USB OTG para teste real;
- cabo/adaptador OTG; para HD externo, preferir hub com alimentação própria.

### Passo a passo

1. Extraia `MeuXboxUSB_8.0.zip` para uma pasta de trabalho.
2. Abra o Android Studio.
3. Escolha **Open** / **Open an Existing Project**.
4. Selecione a pasta `MeuXboxUSB` que contém `settings.gradle` e `gradlew` — não selecione somente `app`.
5. Aceite a sincronização do Gradle quando solicitada.
6. Em **Settings > Build, Execution, Deployment > Build Tools > Gradle**, selecione o **Gradle JDK 17**.
7. Em **SDK Manager**, instale a plataforma Android API 36 e os Build-Tools recomendados.
8. Aguarde a indexação e a sincronização.
9. Se o Android Studio solicitar atualização automática do AGP/Gradle, faça uma cópia do projeto antes. A atualização pode exigir alterações no `build.gradle`.
10. Se o Android Studio pedir o caminho do SDK, ele criará `local.properties`. Esse arquivo é local e não deve ser versionado.
11. Conecte um dispositivo de teste com depuração USB ativada ou crie um emulador para testar apenas a UI. O emulador não substitui o teste de USB OTG.
12. Execute **Build > Make Project** e depois **Run**.

### Compilação pela linha de comando

No Linux/macOS:

```bash
cd MeuXboxUSB
chmod +x gradlew
./gradlew :app:assembleDebug
```

No Windows PowerShell:

```powershell
cd MeuXboxUSB
.\gradlew.bat :app:assembleDebug
```

O APK de debug deve aparecer em:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Para instalar via ADB:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Configuração de release e assinatura

O ZIP contém `release.properties` e um arquivo de texto com nome de keystore dentro de `app/`. Esses arquivos carregam informações de assinatura e devem ser tratados como **secretos comprometidos**.

Recomendação para a continuidade:

1. não reutilizar a senha/keystore exposta no ZIP;
2. revogar/rotacionar a chave de publicação se ela já foi usada;
3. remover arquivos de credenciais do repositório;
4. gerar um novo keystore em local seguro;
5. guardar senhas em `gradle.properties` local, variável de ambiente ou cofre de segredos;
6. adicionar `*.jks`, `*.keystore`, `release.properties` e arquivos de credenciais ao `.gitignore`;
7. configurar explicitamente `signingConfigs` no Gradle apenas em máquina/CI protegido.

O `app/build.gradle` recebido **não referencia `release.properties` nem configura `signingConfigs`**, portanto a presença desse arquivo não significa que o build release já esteja assinado.

## 10. Testes recomendados após abrir no Android Studio

### Teste de instalação

- instalar o APK;
- abrir a tela principal;
- verificar tema claro e escuro;
- abrir tutorial, créditos e diagnóstico;
- abrir o gerenciador sem USB conectado e confirmar mensagem amigável.

### Teste de USB

- conectar pendrive/HD via OTG;
- ignorar qualquer alerta do Android solicitando formatação;
- tocar em **Selecionar Pendrive/HD**;
- conceder a permissão;
- confirmar que o nome e a capacidade aparecem;
- ejetar pelo botão e confirmar que a cópia não está em andamento.

### Teste de transferência

- enviar uma pasta XEX pequena e validar `default.xex`/Title ID;
- escolher `Games` e `Apps` em testes separados;
- enviar uma pasta GOD/STFS;
- testar arquivos avulsos;
- minimizar o app durante a cópia;
- desconectar o cabo apenas em um teste controlado de falha;
- confirmar notificação, progresso, retry e mensagem final;
- repetir uma cópia para verificar o tratamento de arquivos já existentes.

### Teste de catálogo e gerenciador

- escanear jogos instalados;
- conferir nomes mapeados e fallback `ID: XXXXXXXX`;
- abrir detalhes e calcular tamanho;
- filtrar extras;
- testar cópia/cola e backup;
- excluir somente após confirmar que há backup do conteúdo;
- reconectar o USB e escanear novamente.

## 11. Limitações e pontos de atenção encontrados

1. **Acesso ao sistema de arquivos:** `libaums` é usado para USB Mass Storage e o código valida principalmente FAT32. O diagnóstico procura `FATX`, mas encontrar a assinatura não garante que toda a leitura/escrita será suportada pela biblioteca. O suporte real depende do aparelho, versão do Android, particionamento e alimentação.
2. **SAF não substitui acesso bruto ao Xbox:** o armazenamento local do celular é lido via `DocumentFile`, enquanto o destino USB é acessado via libaums. Não confundir os dois fluxos.
3. **Energia e cabo:** HDs podem falhar no `init()` por falta de energia. O código já tenta inicializar até três vezes, mas um hub alimentado pode ser necessário.
4. **Conexão em singleton:** `UsbXboxConnection` não sobrevive à morte do processo. Depois de o sistema matar o app, o usuário pode precisar selecionar o USB novamente.
5. **Internet para capas:** a cópia e o catálogo básico não devem depender de internet, mas as capas podem ficar indisponíveis.
6. **Exclusão sem lixeira:** a exclusão recursiva não é reversível. Faça backup antes de testar.
7. **Versões divergentes:** o README interno menciona melhorias da versão `0.7.8`, enquanto o Gradle declara `0.8.0`. Ao publicar, atualizar changelog, versão e documentação para uma única fonte de verdade.
8. **Build no ambiente analisado:** a primeira execução precisou de permissão de execução no `gradlew`; depois o Gradle 8.13 iniciou, mas o sandbox não tinha Android SDK configurado. A validação final deve ser executada no Android Studio com SDK 36 instalado.
9. **Configuração duplicada:** `gradle.properties` contém duas vezes `org.gradle.unsafe.transform-classpath-instrumentation=false`. É redundante, embora normalmente inofensivo; pode ser limpo em uma manutenção futura.
10. **Privacidade e segurança:** a URL de capa é montada com Title ID e há chamadas externas para recursos de capa. Revisar política de privacidade e disponibilidade desses serviços antes de distribuição pública.

## 12. Checklist de publicação/entrega

- [ ] remover credenciais e keystores do ZIP/repositório;
- [ ] gerar nova assinatura segura;
- [ ] confirmar `versionCode`/`versionName`;
- [ ] instalar e testar em pelo menos um celular com OTG;
- [ ] testar pendrive e HD com alimentação adequada;
- [ ] confirmar comportamento em Android 7/API 24 e Android recente, se esses forem alvos reais;
- [ ] revisar permissões e notificação em Android 13+;
- [ ] atualizar `README` e este documento quando o comportamento mudar;
- [ ] criar backup dos dados do Xbox antes dos testes destrutivos;
- [ ] gerar APK/AAB apenas depois da validação física do USB.
