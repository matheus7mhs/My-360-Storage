# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# ===== Classes de modelo/dados do app =====
# Evita que o R8 remova campos/métodos que parecem "não usados" na análise estática
# mas são necessários (getters usados em outros pontos, construtores, etc.)
-keep class mhs.usb.meuxbox.ListarGames { *; }
-keep class mhs.usb.meuxbox.GameDatabase { *; }

# ===== libaums (acesso USB Mass Storage/FAT32 de baixo nível) =====
# É a parte mais crítica do app (fala direto com o pendrive/HD). Em builds de release
# (minifyEnabled true) o R8 pode ofuscar/remover métodos que a lib usa internamente por
# reflexão ou por contrato de interface entre suas próprias classes, mesmo sem o app
# chamar tudo diretamente -- isso quebraria a conexão USB só no release, nunca aparecendo
# em teste via AndroidIDE (que não minifica). Mantemos a lib inteira intocada para não
# arriscar isso: o ganho de ofuscar/reduzir essa lib específica é insignificante perto do
# risco de quebrar leitura/escrita no drive.
-keep class me.jahnen.libaums.** { *; }
-keepclassmembers class me.jahnen.libaums.** { *; }
-dontwarn me.jahnen.libaums.**

# ===== Stack traces legíveis no Logcat mesmo em release =====
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
