package mhs.usb.meuxbox;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

import me.jahnen.libaums.core.fs.UsbFile;

/**
 * Gerenciador de arquivos básico do drive do Xbox: navega pelas pastas, seleciona
 * itens (toque longo), copia/cola dentro do próprio drive, apaga, e faz backup pro
 * armazenamento do Android via SAF. A cópia de bytes (colar/backup) roda no
 * FileManagerService (foreground service); apagar é feito direto aqui pois é rápido.
 */
public class FileManagerActivity extends AppCompatActivity implements FileManagerAdapter.Listener {

    private static final int REQUEST_CODE_BACKUP_DESTINO = 501;

    private RecyclerView recycler;
    private FileManagerAdapter adapter;
    private final List<UsbFile> itensAtuais = new ArrayList<>();

    private TextView tvCaminho, tvSelecionados, tvPastaVazia, tvClipboardInfo, tvStatusProgresso;
    private TextView tvFmUsbNome, tvFmUsbUso, tvFmUsbLivre;
    private ProgressBar progressFmUsb;
    private LinearLayout layoutFmBreadcrumbs;
    private View layoutAcoes, layoutColar, layoutProgresso;
    private ProgressBar progressFm;
    private ImageButton btnVoltar;

    private UsbFile raiz;
    private UsbFile pastaAtual;
    private final Deque<UsbFile> pilhaNavegacao = new ArrayDeque<>();

    private final List<UsbFile> clipboard = new ArrayList<>();

    private FileManagerService fileManagerService;
    private boolean servicoConectado = false;
    private List<UsbFile> origensPendentesBackup;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            fileManagerService = ((FileManagerService.LocalBinder) binder).getService();
            servicoConectado = true;
            fileManagerService.setListener(opListener);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            servicoConectado = false;
            fileManagerService = null;
        }
    };

    private final FileManagerService.OpListener opListener = new FileManagerService.OpListener() {
        @Override public void onStatus(String status) {
            runOnUiThread(() -> tvStatusProgresso.setText(status));
        }
        @Override public void onProgress(int pct) {
            runOnUiThread(() -> {
                progressFm.setIndeterminate(false);
                progressFm.setProgress(pct);
            });
        }
        @Override public void onFinished(boolean sucesso, String erro, int falhas) {
            runOnUiThread(() -> {
                layoutProgresso.setVisibility(View.GONE);
                if (sucesso && falhas == 0) {
                    Toast.makeText(FileManagerActivity.this, R.string.toast_operacao_concluida, Toast.LENGTH_SHORT).show();
                } else if (sucesso) {
                    Toast.makeText(FileManagerActivity.this, getString(R.string.toast_operacao_concluida_com_falhas_fmt, falhas), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(FileManagerActivity.this, getString(R.string.toast_erro_apagar_fmt, erro), Toast.LENGTH_LONG).show();
                }
                clipboard.clear();
                atualizarBarraColar();
                listarPastaAtual();
                atualizarInfoArmazenamento();
            });
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Tema AUTOMÁTICO: segue o modo claro/escuro do celular.
        ThemeManager.restaurar(this);
        setContentView(R.layout.activity_file_manager);
        setTitle(R.string.title_gerenciador_arquivos);

        // Garante que o banco de nomes de jogos (jogos.csv) está carregado, para que o
        // gerenciador de arquivos mostre o nome do jogo em vez do Title ID nas pastas do Content.
        GameDatabase.inicializar(this);

        if (!UsbXboxConnection.getInstance().isConnected()) {
            Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvCaminho = findViewById(R.id.tv_fm_caminho);
        tvSelecionados = findViewById(R.id.tv_fm_selecionados);
        tvFmUsbNome = findViewById(R.id.tv_fm_usb_nome);
        tvFmUsbUso = findViewById(R.id.tv_fm_usb_uso);
        tvFmUsbLivre = findViewById(R.id.tv_fm_usb_livre);
        progressFmUsb = findViewById(R.id.progress_fm_usb);
        layoutFmBreadcrumbs = findViewById(R.id.layout_fm_breadcrumbs);
        tvPastaVazia = findViewById(R.id.tv_fm_pasta_vazia);
        tvClipboardInfo = findViewById(R.id.tv_fm_clipboard_info);
        tvStatusProgresso = findViewById(R.id.tv_fm_status_progresso);
        layoutAcoes = findViewById(R.id.layout_fm_acoes);
        layoutColar = findViewById(R.id.layout_fm_colar);
        layoutProgresso = findViewById(R.id.layout_fm_progresso);
        progressFm = findViewById(R.id.progress_fm);
        btnVoltar = findViewById(R.id.btn_fm_voltar);
        recycler = findViewById(R.id.recycler_fm);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FileManagerAdapter(itensAtuais, this);
        recycler.setAdapter(adapter);

        raiz = UsbXboxConnection.getInstance().getFileSystem().getRootDirectory();
        pastaAtual = raiz;
        atualizarInfoArmazenamento();

        btnVoltar.setOnClickListener(v -> onBackPressed());

        findViewById(R.id.btn_fm_cancelar_selecao).setOnClickListener(v -> sairModoSelecao());

        findViewById(R.id.btn_fm_copiar).setOnClickListener(v -> {
            clipboard.clear();
            clipboard.addAll(adapter.getSelecionados());
            sairModoSelecao();
            atualizarBarraColar();
        });

        findViewById(R.id.btn_fm_excluir).setOnClickListener(v -> confirmarExcluirSelecionados());

        findViewById(R.id.btn_fm_backup).setOnClickListener(v -> iniciarBackupSelecionados());

        findViewById(R.id.btn_fm_colar).setOnClickListener(v -> colarClipboard());

        findViewById(R.id.btn_fm_limpar_clipboard).setOnClickListener(v -> {
            clipboard.clear();
            atualizarBarraColar();
        });

        listarPastaAtual();

        bindService(new Intent(this, FileManagerService.class), serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (servicoConectado) {
            if (fileManagerService != null) fileManagerService.setListener(null);
            unbindService(serviceConnection);
        }
    }

    @Override
    public void onBackPressed() {
        if (adapter.isModoSelecao()) {
            sairModoSelecao();
            return;
        }
        if (!pilhaNavegacao.isEmpty()) {
            pastaAtual = pilhaNavegacao.pop();
            listarPastaAtual();
            return;
        }
        super.onBackPressed();
    }

    // ==================== Navegação / listagem ====================

    private void listarPastaAtual() {
        new Thread(() -> {
            List<UsbFile> lista = new ArrayList<>();
            try {
                UsbFile[] filhos = pastaAtual.listFiles();
                if (filhos != null) {
                    for (UsbFile f : filhos) lista.add(f);
                    lista.sort(Comparator
                            .comparing((UsbFile f) -> !f.isDirectory())
                            .thenComparing(f -> f.getName().toLowerCase(Locale.getDefault())));
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, getString(R.string.toast_erro_apagar_fmt, e.getMessage()), Toast.LENGTH_SHORT).show());
            }
            runOnUiThread(() -> {
                itensAtuais.clear();
                itensAtuais.addAll(lista);
                // Informa ao adapter o caminho atual ANTES de notificar, para que as pastas
                // de Title ID já sejam rotuladas com o nome do jogo na primeira renderização.
                adapter.setContextoNavegacao(construirCaminhoExibicao(), pastaAtual.getName());
                adapter.notifyDataSetChanged();
                tvPastaVazia.setVisibility(itensAtuais.isEmpty() ? View.VISIBLE : View.GONE);
                tvCaminho.setText(construirCaminhoExibicao());
                atualizarBreadcrumbs();
            });
        }).start();
    }

    private void atualizarInfoArmazenamento() {
        final me.jahnen.libaums.core.fs.FileSystem fs = UsbXboxConnection.getInstance().getFileSystem();
        if (fs == null) return;
        new Thread(() -> {
            try {
                long total = fs.getCapacity();
                long livre = fs.getFreeSpace();
                long usado = Math.max(0L, total - livre);
                int pct = total > 0 ? (int)Math.min(100L, (usado * 100L) / total) : 0;
                runOnUiThread(() -> {
                    tvFmUsbNome.setText(UsbXboxConnection.getInstance().getDeviceLabel());
                    tvFmUsbUso.setText(getString(R.string.label_usb_armazenamento_usado_fmt, formatarTamanho(usado)));
                    tvFmUsbLivre.setText(getString(R.string.label_usb_armazenamento_livre_fmt, formatarTamanho(livre)));
                    progressFmUsb.setProgress(pct);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvFmUsbNome.setText(UsbXboxConnection.getInstance().getDeviceLabel());
                    tvFmUsbUso.setText(R.string.label_usb_armazenamento_indisponivel);
                    tvFmUsbLivre.setText("");
                    progressFmUsb.setProgress(0);
                });
            }
        }).start();
    }

    private String formatarTamanho(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    private void atualizarBreadcrumbs() {
        if (layoutFmBreadcrumbs == null || pastaAtual == null) return;
        layoutFmBreadcrumbs.removeAllViews();

        TextView rootCrumb = criarBreadcrumb(getString(R.string.label_breadcrumb_raiz));
        rootCrumb.setOnClickListener(v -> {
            pilhaNavegacao.clear();
            pastaAtual = raiz;
            adapter.setModoSelecao(false);
            listarPastaAtual();
        });
        layoutFmBreadcrumbs.addView(rootCrumb);

        java.util.List<UsbFile> ancestrais = new java.util.ArrayList<>();
        java.util.Iterator<UsbFile> it = pilhaNavegacao.descendingIterator();
        while (it.hasNext()) ancestrais.add(it.next());

        for (UsbFile destino : ancestrais) {
            TextView sep = criarBreadcrumb("›");
            sep.setTextColor(getColor(R.color.xbox_text_muted));
            layoutFmBreadcrumbs.addView(sep);
            TextView crumb = criarBreadcrumb(destino.getName());
            crumb.setOnClickListener(v -> navegarParaBreadcrumb(destino));
            layoutFmBreadcrumbs.addView(crumb);
        }

        if (pastaAtual != raiz) {
            TextView sep = criarBreadcrumb("›");
            sep.setTextColor(getColor(R.color.xbox_text_muted));
            layoutFmBreadcrumbs.addView(sep);
            TextView atual = criarBreadcrumb(pastaAtual.getName());
            atual.setTextColor(getColor(R.color.xbox_green));
            layoutFmBreadcrumbs.addView(atual);
        }
    }

    private TextView criarBreadcrumb(String texto) {
        TextView tv = new TextView(this);
        tv.setText(texto);
        tv.setTextSize(13);
        tv.setSingleLine(true);
        tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tv.setPadding(10, 6, 10, 6);
        tv.setClickable(true);
        tv.setTextColor(getColor(R.color.xbox_text_primary));
        tv.setBackgroundResource(android.R.drawable.list_selector_background);
        return tv;
    }

    private void navegarParaBreadcrumb(UsbFile destino) {
        java.util.List<UsbFile> novaPilha = new java.util.ArrayList<>();
        java.util.Iterator<UsbFile> it = pilhaNavegacao.descendingIterator();
        while (it.hasNext()) {
            UsbFile f = it.next();
            novaPilha.add(f);
            if (f == destino) break;
        }
        pilhaNavegacao.clear();
        for (int i = novaPilha.size() - 1; i >= 0; i--) pilhaNavegacao.push(novaPilha.get(i));
        pastaAtual = destino;
        listarPastaAtual();
    }

    private String construirCaminhoExibicao() {
        StringBuilder sb = new StringBuilder();
        for (UsbFile f : pilhaNavegacao) {
            String n = f.getName();
            if (n != null && !n.isEmpty()) sb.insert(0, "/" + n);
        }
        String nomeAtual = pastaAtual.getName();
        if (nomeAtual != null && !nomeAtual.isEmpty()) sb.append("/").append(nomeAtual);
        return sb.length() == 0 ? "/" : sb.toString();
    }

    @Override
    public void onAbrirPasta(UsbFile pasta) {
        pilhaNavegacao.push(pastaAtual);
        pastaAtual = pasta;
        listarPastaAtual();
    }

    @Override
    public void onEntrarModoSelecao(UsbFile item) {
        adapter.setModoSelecao(true);
        layoutAcoes.setVisibility(View.VISIBLE);
        layoutColar.setVisibility(View.GONE);
        atualizarContagemSelecao();
    }

    @Override
    public void onToggleSelecao(UsbFile item) {
        atualizarContagemSelecao();
        if (adapter.getQuantidadeSelecionada() == 0) sairModoSelecao();
    }

    private void atualizarContagemSelecao() {
        int qtd = adapter.getQuantidadeSelecionada();
        tvSelecionados.setVisibility(qtd > 0 ? View.VISIBLE : View.GONE);
        tvSelecionados.setText(getString(R.string.label_selecionados_fmt, qtd));
    }

    private void sairModoSelecao() {
        adapter.setModoSelecao(false);
        layoutAcoes.setVisibility(View.GONE);
        tvSelecionados.setVisibility(View.GONE);
        atualizarBarraColar();
    }

    private void atualizarBarraColar() {
        boolean temClipboard = !clipboard.isEmpty() && !adapter.isModoSelecao();
        layoutColar.setVisibility(temClipboard ? View.VISIBLE : View.GONE);
        if (temClipboard) {
            tvClipboardInfo.setText(getString(R.string.label_itens_copiados_fmt, clipboard.size()));
        }
    }

    // ==================== Colar (copiar dentro do drive) ====================

    private void colarClipboard() {
        if (clipboard.isEmpty() || !servicoConectado || fileManagerService == null) return;
        layoutColar.setVisibility(View.GONE);
        mostrarProgresso(getString(R.string.status_preparando_envio));
        fileManagerService.iniciarCopiaInterna(new ArrayList<>(clipboard), pastaAtual);
    }

    // ==================== Excluir ====================

    private void confirmarExcluirSelecionados() {
        List<UsbFile> selecionados = adapter.getSelecionados();
        if (selecionados.isEmpty()) return;

        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_confirmar_exclusao_title)
                .setMessage(getString(R.string.confirmar_apagar_varios_fmt, selecionados.size()))
                .setPositiveButton(R.string.action_apagar, (d, w) -> excluirSelecionados(selecionados))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void excluirSelecionados(List<UsbFile> selecionados) {
        sairModoSelecao();
        mostrarProgresso(getString(R.string.status_apagando));
        new Thread(() -> {
            int falhas = 0;
            for (UsbFile f : selecionados) {
                try {
                    UsbXboxConnection.deletarRecursivo(f);
                } catch (Exception e) {
                    falhas++;
                }
            }
            int falhasFinal = falhas;
            runOnUiThread(() -> {
                layoutProgresso.setVisibility(View.GONE);
                if (falhasFinal == 0) {
                    Toast.makeText(this, R.string.toast_apagado_com_sucesso, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, getString(R.string.toast_operacao_concluida_com_falhas_fmt, falhasFinal), Toast.LENGTH_LONG).show();
                }
                listarPastaAtual();
            });
        }).start();
    }

    // ==================== Backup para o Android ====================

    private void iniciarBackupSelecionados() {
        List<UsbFile> selecionados = adapter.getSelecionados();
        if (selecionados.isEmpty()) return;
        origensPendentesBackup = selecionados;

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(intent, REQUEST_CODE_BACKUP_DESTINO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_BACKUP_DESTINO || resultCode != RESULT_OK || data == null) return;

        Uri treeUri = data.getData();
        if (treeUri == null || origensPendentesBackup == null) return;

        try {
            getContentResolver().takePersistableUriPermission(treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) {}

        DocumentFile pastaDestino = DocumentFile.fromTreeUri(this, treeUri);
        if (pastaDestino == null || !servicoConectado || fileManagerService == null) {
            Toast.makeText(this, R.string.toast_erro_selecionar_pasta_destino, Toast.LENGTH_SHORT).show();
            return;
        }

        List<UsbFile> origens = origensPendentesBackup;
        origensPendentesBackup = null;
        sairModoSelecao();
        mostrarProgresso(getString(R.string.status_preparando_envio));
        fileManagerService.iniciarBackup(origens, pastaDestino);
    }

    private void mostrarProgresso(String statusInicial) {
        progressFm.setIndeterminate(true);
        tvStatusProgresso.setText(statusInicial);
        layoutProgresso.setVisibility(View.VISIBLE);
    }
}
