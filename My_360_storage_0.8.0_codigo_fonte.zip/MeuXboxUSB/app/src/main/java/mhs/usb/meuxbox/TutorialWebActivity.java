package mhs.usb.meuxbox;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Exibe o tutorial completo (HTML com capturas de tela, em PT/EN/ES) empacotado
 * localmente em assets/tutorial/ -- funciona offline, sem depender de link externo.
 */
public class TutorialWebActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Tema AUTOMÁTICO: segue o modo claro/escuro do celular.
        ThemeManager.restaurar(this);
        setContentView(R.layout.activity_tutorial_web);

        WebView webView = findViewById(R.id.webview_tutorial);
        ProgressBar progress = findViewById(R.id.progress_tutorial_web);
        findViewById(R.id.btn_tutorial_web_fechar).setOnClickListener(v -> finish());

        // JavaScript é necessário só pro seletor de idioma (troca de seção via classe CSS),
        // não há nenhuma chamada de rede -- tudo roda a partir dos assets locais.
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
            }
        });

        // Passa o tema atual na URL para o HTML servir a versão clara/escura do tutorial.
        String tema = ThemeManager.isModoClaro(this) ? "?tema=branco" : "";
        webView.loadUrl("file:///android_asset/tutorial/index.html" + tema);
    }

    @Override
    public void onBackPressed() {
        WebView webView = findViewById(R.id.webview_tutorial);
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
