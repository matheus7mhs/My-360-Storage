package mhs.usb.meuxbox;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import me.jahnen.libaums.core.UsbMassStorageDevice;

public class MainActivity extends AppCompatActivity {

    private TextView tvDestinoAtual, tvUsbStorageSummary;
    private ProgressBar progressUsbStorage;
    private Button btnSelecionarDestino;
    private Button btnEjetar;
    private ProgressBar progressIndividual, progressTotal;
    private TextView tvCurrentFile, tvPctIndividual, tvPctTotal, tvFileCount;
    private Button btnSelectFolder;
    private Button btnEnviarAvulso;

    private ImageView imgCurrentGame;
    private TextView tvCurrentGameName;

    private static final int REQUEST_CODE_SOURCE = 999;
    private static final int REQUEST_CODE_ARQUIVOS_AVULSOS = 998;

    public static final String PREFS_NAME = "XboxUsbPrefs";
    private static final String ACTION_USB_PERMISSION = "mhs.usb.meuxbox.USB_PERMISSION";

    private String currentTitleId = null;
    private String currentGameName = null;

    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private UsbManager usbManager;

    // ---- Ligação com o TransferService (a cópia roda nele, não na Activity) ----
    private TransferService transferService;
    private boolean serviceBound = false;

    private DocumentFile pendingRootDir;
    private String pendingXexDest;
    private String pendingTitleIdMarker;

    private java.util.List<DocumentFile> pendingArquivosAvulsos;
    private String pendingPastaDestinoAvulsos;

    private final BroadcastReceiver usbPermissionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;

            UsbDevice usbDevice = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);

            if (granted && usbDevice != null) {
                conectarAoDispositivo(usbDevice);
            } else {
                Toast.makeText(MainActivity.this, R.string.toast_permissao_usb_negada, Toast.LENGTH_SHORT).show();
            }
        }
    };

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            TransferService.LocalBinder binder = (TransferService.LocalBinder) service;
            transferService = binder.getService();
            serviceBound = true;
            transferService.setListener(progressListener);

            if (transferService.isTransferEmAndamento()) {
                btnSelectFolder.setEnabled(false);
                if (btnEnviarAvulso != null) btnEnviarAvulso.setEnabled(false);
            } else if (pendingRootDir != null || pendingArquivosAvulsos != null) {
                dispararTransferenciaPendente();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            transferService = null;
        }
    };

    private final TransferService.ProgressListener progressListener = new TransferService.ProgressListener() {
        @Override
        public void onStatus(String status) {
            runOnUiThread(() -> {
                if (status != null) tvCurrentFile.setText(status);
            });
        }

        @Override
        public void onFileCount(int done, int total) {
            runOnUiThread(() -> tvFileCount.setText(getString(R.string.label_arquivos_count_fmt, done, total)));
        }

        @Override
        public void onProgress(int individualPct, int totalPct) {
            runOnUiThread(() -> {
                progressIndividual.setProgress(individualPct);
                tvPctIndividual.setText(individualPct + "%");
                progressTotal.setProgress(totalPct);
                tvPctTotal.setText(totalPct + "%");
            });
        }

        @Override
        public void onGameInfo(String gameName, String titleId) {
            runOnUiThread(() -> {
                if (gameName != null) {
                    currentGameName = gameName;
                    currentTitleId = titleId;
                    tvCurrentGameName.setText(gameName);
                    if (titleId != null) {
                        imgCurrentGame.setTag(titleId);
                        carregarImagemComCache(titleId, "https://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId, imgCurrentGame);
                    }
                }
            });
        }

        @Override
        public void onFinished(boolean success, String errorMsg) {
            runOnUiThread(() -> {
                btnSelectFolder.setEnabled(true);
                if (btnEnviarAvulso != null) btnEnviarAvulso.setEnabled(true);
                if (success) {
                    tocarSom(R.raw.sucesso);
                    Toast.makeText(MainActivity.this, R.string.toast_transferencia_concluida, Toast.LENGTH_LONG).show();
                } else if (errorMsg != null) {
                    tocarSom(R.raw.erro);
                    boolean falhaConexaoUsb = errorMsg.contains("MAX_RECOVERY_ATTEMPTS")
                            || errorMsg.contains("Could not read from device")
                            || errorMsg.contains("Could not write");

                    if (falhaConexaoUsb) {
                        // A conexão provavelmente ficou instável/travada -- força uma reconexão
                        // do zero na próxima tentativa em vez de deixar o app achar que ainda
                        // está tudo bem com um estado que já se mostrou problemático.
                        UsbXboxConnection.getInstance().disconnect();
                        atualizarTextoDestino();
                    }

                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.dialog_transferencia_abortada_title)
                        .setMessage(falhaConexaoUsb
                                ? getString(R.string.dialog_falha_conexao_usb_message)
                                : getString(R.string.dialog_transferencia_abortada_message_fmt, errorMsg))
                        .setPositiveButton(R.string.action_ok, null)
                        .setCancelable(false)
                        .show();
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Tema AUTOMÁTICO: segue o modo claro/escuro configurado no celular.
        ThemeManager.restaurar(this);
        setContentView(R.layout.activity_main);

        GameDatabase.inicializar(this);

        tvDestinoAtual = findViewById(R.id.tv_destino_atual);
        tvUsbStorageSummary = findViewById(R.id.tv_usb_storage_summary);
        progressUsbStorage = findViewById(R.id.progress_usb_storage);
        btnSelecionarDestino = findViewById(R.id.btn_selecionar_destino);
        btnEjetar = findViewById(R.id.btn_ejetar_destino);
        progressIndividual = findViewById(R.id.progress_individual);
        progressTotal = findViewById(R.id.progress_total);
        tvCurrentFile = findViewById(R.id.tv_current_file);
        tvPctIndividual = findViewById(R.id.tv_pct_individual);
        tvPctTotal = findViewById(R.id.tv_pct_total);
        tvFileCount = findViewById(R.id.tv_file_count);
        btnSelectFolder = findViewById(R.id.btn_select_folder);
        btnEnviarAvulso = findViewById(R.id.btn_enviar_avulso);

        imgCurrentGame = findViewById(R.id.img_current_game);
        tvCurrentGameName = findViewById(R.id.tv_current_game_name);

        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbPermissionReceiver, filter);
        }

        verificarPermissoes();
        atualizarTextoDestino();

        btnSelecionarDestino.setOnClickListener(v -> conectarDestinoUsb());

        if (btnEjetar != null) {
            btnEjetar.setOnClickListener(v -> ejetarDispositivo());
        }

        if (btnEnviarAvulso != null) {
            btnEnviarAvulso.setOnClickListener(v -> {
                if (!UsbXboxConnection.getInstance().isConnected()) {
                    Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, REQUEST_CODE_ARQUIVOS_AVULSOS);
            });
        }

        Button btnDiagnostico = findViewById(R.id.btn_diagnostico_usb);
        if (btnDiagnostico != null) {
            btnDiagnostico.setOnClickListener(v ->
                    startActivity(new Intent(MainActivity.this, UsbDiagActivity.class)));
        }

        Button btnAbrirJogos = findViewById(R.id.btn_abrir_jogos);
        if (btnAbrirJogos != null) {
            btnAbrirJogos.setOnClickListener(v -> {
                getSupportFragmentManager().beginTransaction()
                    .replace(android.R.id.content, new MeusJogosFragment())
                    .addToBackStack(null)
                    .commit();
            });
        }

        Button btnGerenciadorArquivos = findViewById(R.id.btn_abrir_gerenciador_arquivos);
        if (btnGerenciadorArquivos != null) {
            btnGerenciadorArquivos.setOnClickListener(v -> {
                if (!UsbXboxConnection.getInstance().isConnected()) {
                    Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
                    return;
                }
                startActivity(new Intent(MainActivity.this, FileManagerActivity.class));
            });
        }

        btnSelectFolder.setOnClickListener(v -> {
            if (!UsbXboxConnection.getInstance().isConnected()) {
                Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
                return;
            }

            currentGameName = null;
            currentTitleId = null;
            tvCurrentGameName.setText(R.string.status_aguardando_analise);
            imgCurrentGame.setImageResource(android.R.drawable.ic_menu_gallery);

            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, REQUEST_CODE_SOURCE);
        });

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean primeiroUso = prefs.getBoolean("primeiro_uso", true);
        if (primeiroUso) {
            mostrarTutorial();
            prefs.edit().putBoolean("primeiro_uso", false).apply();
        }

        Button btnInfo = findViewById(R.id.btn_info_app);
        if (btnInfo != null) {
            btnInfo.setOnClickListener(v -> mostrarInfoCreditos());
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        atualizarTextoDestino();
        // Tenta se conectar a um TransferService que já esteja rodando (transferência em andamento).
        // Flag 0 (sem BIND_AUTO_CREATE) faz com que NADA seja criado se não houver transferência ativa.
        Intent intent = new Intent(this, TransferService.class);
        bindService(intent, serviceConnection, 0);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (serviceBound) {
            if (transferService != null) {
                transferService.setListener(null);
            }
            unbindService(serviceConnection);
            serviceBound = false;
            transferService = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(usbPermissionReceiver); } catch (Exception ignored) {}
    }

    // ================== Conexão com o pendrive/HD do Xbox via libaums ==================

    private void conectarDestinoUsb() {
        UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(this);
        if (devices == null || devices.length == 0) {
            Toast.makeText(this, R.string.toast_nenhum_usb_detectado, Toast.LENGTH_LONG).show();
            return;
        }

        UsbMassStorageDevice device = devices[0];
        UsbDevice usbDevice = device.getUsbDevice();

        if (usbManager.hasPermission(usbDevice)) {
            conectarAoDispositivo(usbDevice);
        } else {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), flags);
            usbManager.requestPermission(usbDevice, permissionIntent);
        }
    }

    private void conectarAoDispositivo(UsbDevice usbDevice) {
        tvDestinoAtual.setText(R.string.label_conectando_destino);

        new Thread(() -> {
            try {
                UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(this);
                UsbMassStorageDevice alvo = null;
                for (UsbMassStorageDevice d : devices) {
                    if (d.getUsbDevice().getDeviceId() == usbDevice.getDeviceId()) {
                        alvo = d;
                        break;
                    }
                }
                if (alvo == null) throw new Exception(getString(R.string.erro_dispositivo_desconectado));

                UsbXboxConnection.getInstance().conectar(alvo);

                runOnUiThread(() -> {
                    atualizarTextoDestino();
                    Toast.makeText(this, R.string.toast_destino_configurado, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                String errorMsg = e.getMessage();
                boolean falhaConexaoUsb = errorMsg != null && (
                        errorMsg.contains("MAX_RECOVERY_ATTEMPTS")
                        || errorMsg.contains("Could not read from device")
                        || errorMsg.contains("Could not write"));

                runOnUiThread(() -> {
                    atualizarTextoDestino();
                    if (falhaConexaoUsb) {
                        new AlertDialog.Builder(this)
                            .setTitle(R.string.dialog_transferencia_abortada_title)
                            .setMessage(R.string.dialog_falha_conexao_usb_message)
                            .setPositiveButton(R.string.action_ok, null)
                            .setCancelable(false)
                            .show();
                    } else {
                        Toast.makeText(this, getString(R.string.toast_erro_conectar_destino_fmt, errorMsg), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void atualizarTextoDestino() {
        boolean conectado = UsbXboxConnection.getInstance().isConnected();
        if (conectado) {
            tvDestinoAtual.setText(getString(R.string.label_destino_atual_fmt, UsbXboxConnection.getInstance().getDeviceLabel()));
            atualizarResumoArmazenamentoUsb();
        } else {
            tvDestinoAtual.setText(R.string.label_nenhum_destino_selecionado);
            if (tvUsbStorageSummary != null) tvUsbStorageSummary.setText(R.string.label_usb_armazenamento_indisponivel);
            if (progressUsbStorage != null) progressUsbStorage.setProgress(0);
        }
        if (btnEjetar != null) {
            btnEjetar.setEnabled(conectado);
        }
    }

    private void atualizarResumoArmazenamentoUsb() {
        final me.jahnen.libaums.core.fs.FileSystem fs = UsbXboxConnection.getInstance().getFileSystem();
        if (fs == null || tvUsbStorageSummary == null) return;
        executor.execute(() -> {
            try {
                long total = fs.getCapacity();
                long livre = fs.getFreeSpace();
                long usado = Math.max(0L, total - livre);
                int pct = total > 0 ? (int)Math.min(100L, (usado * 100L) / total) : 0;
                String resumo = getString(R.string.label_usb_storage_resumo_fmt,
                        formatarTamanhoUsb(usado), formatarTamanhoUsb(total), formatarTamanhoUsb(livre));
                runOnUiThread(() -> {
                    tvUsbStorageSummary.setText(resumo);
                    if (progressUsbStorage != null) progressUsbStorage.setProgress(pct);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvUsbStorageSummary.setText(R.string.label_usb_armazenamento_indisponivel);
                    if (progressUsbStorage != null) progressUsbStorage.setProgress(0);
                });
            }
        });
    }

    private String formatarTamanhoUsb(long bytes) {
        if (bytes < 1024L * 1024L) return String.format(java.util.Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(java.util.Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    /**
     * Fecha a conexão USB de forma limpa antes do usuário desconectar fisicamente o cabo/drive.
     * Assim como "ejetar" um pendrive no PC, isso evita deixar a cadeia de clusters do FAT em
     * estado inconsistente caso o drive fosse desconectado no meio de alguma operação pendente.
     */
    private void ejetarDispositivo() {
        if (serviceBound && transferService != null && transferService.isTransferEmAndamento()) {
            Toast.makeText(this, R.string.toast_nao_ejetar_durante_transferencia, Toast.LENGTH_LONG).show();
            return;
        }

        UsbXboxConnection.getInstance().disconnect();
        atualizarTextoDestino();
        Toast.makeText(this, R.string.toast_dispositivo_ejetado, Toast.LENGTH_SHORT).show();
    }

    // ================== Restante do fluxo (seleção de origem, cópia, UI) ==================

    private void exibirInfoDoJogo(String titleId) {
        currentTitleId = titleId;
        currentGameName = GameDatabase.getNomeDoJogo(titleId);
        String url = "https://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId;

        runOnUiThread(() -> {
            tvCurrentGameName.setText(currentGameName);
            imgCurrentGame.setTag(titleId);
            carregarImagemComCache(titleId, url, imgCurrentGame);
        });
    }

    private void exibirInfoDoJogoXex(String nomePasta) {
        currentTitleId = null;
        currentGameName = getString(R.string.game_name_xex_fmt, nomePasta);
        runOnUiThread(() -> {
            tvCurrentGameName.setText(currentGameName);
            imgCurrentGame.setImageResource(android.R.drawable.ic_menu_gallery);
        });
    }

    private void carregarImagemComCache(String titleId, String urlStr, ImageView imageView) {
        File cacheDir = new File(getCacheDir(), "xbox_covers");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        File imageFile = new File(cacheDir, titleId + ".jpg");

        if (imageFile.exists()) {
            executor.execute(() -> {
                Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                mainHandler.post(() -> {
                    if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                        imageView.setImageBitmap(bitmap);
                    }
                });
            });
            return;
        }

        executor.execute(() -> {
            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(3000);
                conn.connect();

                if (conn.getResponseCode() == 200) {
                    InputStream input = conn.getInputStream();
                    FileOutputStream output = new FileOutputStream(imageFile);
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                    output.close(); input.close();

                    Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                    mainHandler.post(() -> {
                        if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                            imageView.setImageBitmap(bitmap);
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private Bitmap decodificarReduzido(String path, int targetW, int targetH) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);

            int sampleSize = 1;
            int largura = bounds.outWidth, altura = bounds.outHeight;
            while ((largura / (sampleSize * 2)) >= targetW && (altura / (sampleSize * 2)) >= targetH) {
                sampleSize *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            return BitmapFactory.decodeFile(path, options);
        } catch (Exception e) {
            return null;
        }
    }

    private void tocarSom(int resId) {
        try {
            MediaPlayer mp = new MediaPlayer();
            android.media.AudioAttributes attributes = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            mp.setAudioAttributes(attributes);
            android.content.res.AssetFileDescriptor afd = getResources().openRawResourceFd(resId);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setVolume(1.0f, 1.0f);
            mp.prepare();
            mp.setOnCompletionListener(MediaPlayer::release);
            mp.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQUEST_CODE_SOURCE) {
            if (data.getData() == null) return;
            DocumentFile root = DocumentFile.fromTreeUri(this, data.getData());
            if (root != null) {
                try {
                    getContentResolver().takePersistableUriPermission(data.getData(),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                btnSelectFolder.setEnabled(false);
                tvCurrentFile.setText(R.string.status_procurando_executaveis);
                verificarTipoEIniciar(root);
            }
        } else if (requestCode == REQUEST_CODE_ARQUIVOS_AVULSOS) {
            java.util.List<DocumentFile> arquivos = new java.util.ArrayList<>();

            if (data.getClipData() != null) {
                android.content.ClipData clip = data.getClipData();
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri uri = clip.getItemAt(i).getUri();
                    adicionarArquivoSelecionado(uri, arquivos);
                }
            } else if (data.getData() != null) {
                adicionarArquivoSelecionado(data.getData(), arquivos);
            }

            if (arquivos.isEmpty()) {
                Toast.makeText(this, R.string.toast_nenhum_arquivo, Toast.LENGTH_SHORT).show();
                return;
            }

            mostrarDialogoPastaDestino(arquivos);
        }
    }

    private void adicionarArquivoSelecionado(Uri uri, java.util.List<DocumentFile> destino) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        DocumentFile f = DocumentFile.fromSingleUri(this, uri);
        if (f != null && f.isFile()) destino.add(f);
    }

    /** Pergunta em qual subpasta do drive do Xbox os arquivos avulsos devem ser copiados. */
    private void mostrarDialogoPastaDestino(java.util.List<DocumentFile> arquivos) {
        android.widget.EditText input = new android.widget.EditText(this);
        input.setHint(R.string.hint_pasta_destino_avulsos);
        input.setSingleLine(true);

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout container = new android.widget.FrameLayout(this);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = pad; lp.rightMargin = pad; lp.topMargin = pad / 2; lp.bottomMargin = 0;
        input.setLayoutParams(lp);
        container.addView(input);

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_pasta_destino_title_fmt, arquivos.size()))
                .setMessage(R.string.dialog_pasta_destino_message)
                .setView(container)
                .setPositiveButton(R.string.btn_enviar, (dialog, which) -> {
                    String pasta = input.getText() != null ? input.getText().toString() : "";
                    iniciarTransferenciaArquivosAvulsos(arquivos, pasta);
                })
                .setNegativeButton(R.string.action_cancelar, null)
                .show();
    }

    private DocumentFile procurarDefaultXex(DocumentFile dir, int depth) {
        if (depth > 3 || dir == null) return null;
        DocumentFile[] files = dir.listFiles();
        if (files == null) return null;

        for (DocumentFile f : files) {
            if (f.isFile() && f.getName() != null && f.getName().equalsIgnoreCase("default.xex")) {
                return f;
            }
        }
        for (DocumentFile f : files) {
            if (f.isDirectory()) {
                DocumentFile found = procurarDefaultXex(f, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private boolean contemXexProfundo(DocumentFile dir, int depth) {
        if (depth > 3 || dir == null) return false;
        DocumentFile[] files = dir.listFiles();
        if (files == null) return false;
        for (DocumentFile f : files) {
            if (f.isFile() && f.getName() != null && f.getName().toLowerCase().endsWith(".xex")) return true;
        }
        for (DocumentFile f : files) {
            if (f.isDirectory() && contemXexProfundo(f, depth + 1)) return true;
        }
        return false;
    }

    private void verificarTipoEIniciar(DocumentFile rootDir) {
        new Thread(() -> {
            boolean temXex = contemXexProfundo(rootDir, 0);
            String titleIdEncontrado = null;

            if (temXex) {
                DocumentFile defaultXex = procurarDefaultXex(rootDir, 0);
                if (defaultXex != null) {
                    titleIdEncontrado = XexParser.getTitleId(MainActivity.this, defaultXex);
                }
            }

            final String finalTitleId = titleIdEncontrado;

            runOnUiThread(() -> {
                if (temXex) {
                    if (finalTitleId != null) {
                        exibirInfoDoJogo(finalTitleId);
                    } else {
                        exibirInfoDoJogoXex(rootDir.getName());
                    }

                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.dialog_xex_detectado_title)
                        .setMessage(R.string.dialog_xex_detectado_message)
                        .setPositiveButton(R.string.btn_pasta_jogos, (dialog, which) -> {
                            iniciarTransferencia(rootDir, "Games", finalTitleId);
                        })
                        .setNegativeButton(R.string.btn_pasta_apps, (dialog, which) -> {
                            iniciarTransferencia(rootDir, "Apps", finalTitleId);
                        })
                        .setNeutralButton(R.string.action_cancelar, (dialog, which) -> {
                            btnSelectFolder.setEnabled(true);
                            tvCurrentFile.setText(R.string.status_aguardando);
                            tvCurrentGameName.setText(R.string.default_no_game_selected);
                        })
                        .setCancelable(false)
                        .show();
                } else {
                    iniciarTransferencia(rootDir, null, null);
                }
            });
        }).start();
    }

    /**
     * Prepara e dispara a cópia através do TransferService (Foreground Service),
     * garantindo que ela continue mesmo se o app for para segundo plano.
     */
    private void iniciarTransferencia(DocumentFile rootDir, String xexDest, String titleIdMarker) {
        if (!UsbXboxConnection.getInstance().isConnected()) {
            Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
            btnSelectFolder.setEnabled(true);
            return;
        }

        pendingRootDir = rootDir;
        pendingXexDest = xexDest;
        pendingTitleIdMarker = titleIdMarker;

        tvCurrentFile.setText(R.string.status_preparando_envio);
        btnSelectFolder.setEnabled(false);

        Intent svcIntent = new Intent(this, TransferService.class);
        ContextCompat.startForegroundService(this, svcIntent);

        if (serviceBound && transferService != null) {
            dispararTransferenciaPendente();
        } else {
            bindService(svcIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    /**
     * Prepara e dispara o envio de arquivos avulsos (mídia, plugins, etc.) através do
     * TransferService, para uma subpasta escolhida pelo usuário dentro do drive do Xbox.
     */
    private void iniciarTransferenciaArquivosAvulsos(java.util.List<DocumentFile> arquivos, String pastaDestino) {
        if (!UsbXboxConnection.getInstance().isConnected()) {
            Toast.makeText(this, R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
            return;
        }

        pendingArquivosAvulsos = arquivos;
        pendingPastaDestinoAvulsos = pastaDestino;

        tvCurrentGameName.setText(R.string.label_enviando_arquivos_avulsos);
        imgCurrentGame.setImageResource(android.R.drawable.ic_menu_gallery);
        tvCurrentFile.setText(R.string.status_preparando_envio);
        btnSelectFolder.setEnabled(false);
        if (btnEnviarAvulso != null) btnEnviarAvulso.setEnabled(false);

        Intent svcIntent = new Intent(this, TransferService.class);
        ContextCompat.startForegroundService(this, svcIntent);

        if (serviceBound && transferService != null) {
            dispararTransferenciaPendente();
        } else {
            bindService(svcIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    private void dispararTransferenciaPendente() {
        if (transferService == null) return;

        if (!UsbXboxConnection.getInstance().isConnected()) {
            Toast.makeText(this, R.string.toast_destino_inacessivel, Toast.LENGTH_SHORT).show();
            btnSelectFolder.setEnabled(true);
            if (btnEnviarAvulso != null) btnEnviarAvulso.setEnabled(true);
            pendingRootDir = null;
            pendingArquivosAvulsos = null;
            return;
        }

        if (pendingRootDir != null) {
            String nomeFallback = currentGameName != null ? currentGameName : pendingRootDir.getName();
            transferService.iniciarTransferencia(pendingRootDir, pendingXexDest, pendingTitleIdMarker, nomeFallback);
            pendingRootDir = null;
            pendingXexDest = null;
            pendingTitleIdMarker = null;
        } else if (pendingArquivosAvulsos != null) {
            String nomeFallback = getString(R.string.label_enviando_arquivos_avulsos);
            transferService.iniciarTransferenciaArquivosAvulsos(pendingArquivosAvulsos, pendingPastaDestinoAvulsos, nomeFallback);
            pendingArquivosAvulsos = null;
            pendingPastaDestinoAvulsos = null;
        }
    }

    private void verificarPermissoes() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void mostrarTutorial() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_tutorial);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);

        // Largura responsiva: 90% da tela no celular, limitada a ~520 dp em telas grandes.
        int width = ScreenUtils.larguraDialogoPx(this);
        dialog.getWindow().setLayout(width, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

        Button btnEntendi = dialog.findViewById(R.id.btn_entendi_tutorial);
        btnEntendi.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void mostrarInfoCreditos() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_info_creditos);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));

        // Largura responsiva: 90% da tela no celular, limitada a ~520 dp em telas grandes.
        int width = ScreenUtils.larguraDialogoPx(this);
        dialog.getWindow().setLayout(width, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView devTitulo = dialog.findViewById(R.id.tv_cred_dev_titulo);
        TextView devNome = dialog.findViewById(R.id.tv_cred_dev_nome);
        TextView gtTitulo = dialog.findViewById(R.id.tv_cred_gt_titulo);
        TextView gtNome = dialog.findViewById(R.id.tv_cred_gt_nome);
        TextView agradecimentos = dialog.findViewById(R.id.tv_cred_agradecimentos);
        Button btnFechar = dialog.findViewById(R.id.btn_fechar_info);
        Button btnVerTutorial = dialog.findViewById(R.id.btn_ver_tutorial_info);

        devTitulo.setText(R.string.credits_dev_titulo);
        devNome.setText(R.string.credits_dev_nome);
        gtTitulo.setText(R.string.credits_apis_titulo);
        gtNome.setText(R.string.credits_apis_lista);
        agradecimentos.setText(R.string.credits_rodape);

        btnVerTutorial.setOnClickListener(v -> {
            dialog.dismiss();
            startActivity(new Intent(MainActivity.this, TutorialWebActivity.class));
        });
        btnFechar.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }
}
