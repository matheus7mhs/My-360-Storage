package mhs.usb.meuxbox;

import android.content.Context;
import android.util.DisplayMetrics;

/**
 * Utilitário de adaptabilidade de tela.
 *
 * Responsividade celular → tablet → desktop:
 * - spanCount(): número de colunas da grade de jogos conforme a menor largura
 *   disponível da tela: 2 (celular) → 3 → 4 (tablet) → 5 → 6 (desktop).
 * - larguraDialogoPx(): largura de diálogos: 90% da tela no celular,
 *   limitada a ~520 dp em telas maiores para não esticar.
 * - isTabletLike(): true em telas largas (usado para decisões de UI).
 */
public final class ScreenUtils {

    private ScreenUtils() {
    }

    /**
     * Largura disponível em dp (usando o menor lado).
     */
    public static int menorLarguraDp(Context context) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        return (int) (Math.min(dm.widthPixels, dm.heightPixels) / dm.density);
    }

    /**
     * Número de colunas da grade de jogos conforme a largura de tela.
     */
    public static int spanCount(Context context) {
        int dp = menorLarguraDp(context);
        if (dp >= 1280) return 6;   // desktop / TV
        if (dp >= 1024) return 5;   // tablets grandes / landscape
        if (dp >= 840) return 4;    // tablets pequenos
        if (dp >= 600) return 3;    // phablets / celulares grandes em landscape
        return 2;                   // celular comum
    }

    /**
     * Largura, em pixels, para diálogos: 90% da tela no celular;
     * limitada a 520 dp em telas maiores.
     */
    public static int larguraDialogoPx(Context context) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int telaPx = dm.widthPixels;
        int maxPx = (int) (520 * dm.density);
        return Math.min((int) (telaPx * 0.90f), maxPx);
    }

    /**
     * True quando a tela é do tipo tablet/desktop (>= 600 dp).
     */
    public static boolean isTabletLike(Context context) {
        return menorLarguraDp(context) >= 600;
    }
}
