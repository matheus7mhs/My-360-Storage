package mhs.usb.meuxbox;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

import me.jahnen.libaums.core.UsbMassStorageDevice;
import me.jahnen.libaums.core.partition.Partition;

/**
 * Tela de DIAGNÓSTICO (somente leitura) para o pendrive/HD do Xbox 360.
 *
 * Não usa o Storage Access Framework do Android (que não sabe ler FATX).
 * Em vez disso, fala diretamente com o dispositivo USB Mass Storage através da
 * biblioteca libaums, e lê o primeiro setor (512 bytes) de cada partição pra
 * conferir se acha a assinatura "FATX" usada pelo Xbox 360.
 *
 * ESTA TELA NUNCA ESCREVE NO DISPOSITIVO. Serve só pra validar, no seu hardware
 * real, se conseguimos falar com o drive antes de avançarmos para leitura/escrita
 * de arquivos de verdade.
 */
public class UsbDiagActivity extends AppCompatActivity {

    private static final String ACTION_USB_PERMISSION = "mhs.usb.meuxbox.USB_PERMISSION";

    private TextView tvLog;
    private UsbManager usbManager;
    private UsbMassStorageDevice[] massStorageDevices;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                if (granted && device != null) {
                    log("Permissão concedida para: " + device.getDeviceName());
                    inspecionarComPermissaoConcedida();
                } else {
                    log("Permissão NEGADA pelo usuário para o dispositivo.");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Tema AUTOMÁTICO: segue o modo claro/escuro do celular.
        ThemeManager.restaurar(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(ContextCompat.getColor(this, R.color.xbox_bg));
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Diagnóstico USB (Xbox 360)");
        tvTitle.setTextSize(18);
        tvTitle.setTextColor(ContextCompat.getColor(this, R.color.xbox_green));
        tvTitle.setPadding(0, 0, 0, pad);

        Button btnScan = new Button(this);
        btnScan.setText("Procurar Dispositivos USB");
        btnScan.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_button_primary));
        btnScan.setOnClickListener(v -> procurarDispositivos());

        tvLog = new TextView(this);
        tvLog.setTextIsSelectable(true);
        tvLog.setTextSize(12);
        tvLog.setTextColor(ContextCompat.getColor(this, R.color.xbox_text_primary));
        tvLog.setPadding(0, pad, 0, 0);
        tvLog.setText("Conecte o pendrive/HD via OTG e toque no botão acima.\n\nEsta tela é apenas leitura: não grava nada no dispositivo.\n");

        layout.addView(tvTitle);
        layout.addView(btnScan);
        layout.addView(tvLog);
        scroll.addView(layout);
        setContentView(scroll);

        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
    }

    private void log(String msg) {
        runOnUiThread(() -> tvLog.append(msg + "\n"));
    }

    private void procurarDispositivos() {
        tvLog.setText("");
        massStorageDevices = UsbMassStorageDevice.getMassStorageDevices(this);

        if (massStorageDevices == null || massStorageDevices.length == 0) {
            log("Nenhum dispositivo de armazenamento USB detectado pela libaums.\n" +
                "Verifique o cabo/adaptador OTG e se o HD tem alimentação suficiente " +
                "(HDs externos sem fonte própria costumam falhar aqui).");
            return;
        }

        log("Encontrado(s) " + massStorageDevices.length + " dispositivo(s) de armazenamento USB.\n");

        for (UsbMassStorageDevice device : massStorageDevices) {
            UsbDevice usbDevice = device.getUsbDevice();
            log("- " + safeName(usbDevice) + " (VID:" + usbDevice.getVendorId() + " PID:" + usbDevice.getProductId() + ")");

            if (usbManager.hasPermission(usbDevice)) {
                inspecionarDispositivo(device);
            } else {
                log("  Solicitando permissão ao Android...");
                int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0);
                PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), flags);
                usbManager.requestPermission(usbDevice, permissionIntent);
            }
        }
    }

    private String safeName(UsbDevice d) {
        try {
            String n = d.getProductName();
            return n != null ? n : d.getDeviceName();
        } catch (Exception e) {
            return d.getDeviceName();
        }
    }

    private void inspecionarComPermissaoConcedida() {
        if (massStorageDevices == null) return;
        for (UsbMassStorageDevice device : massStorageDevices) {
            if (usbManager.hasPermission(device.getUsbDevice())) {
                inspecionarDispositivo(device);
            }
        }
    }

    private void inspecionarDispositivo(UsbMassStorageDevice device) {
        new Thread(() -> {
            try {
                device.init();
                List<Partition> partitions = device.getPartitions();
                log("  " + partitions.size() + " partição(ões) encontrada(s) neste dispositivo.");

                for (int i = 0; i < partitions.size(); i++) {
                    Partition p = partitions.get(i);
                    log("  Partição " + i + ":");
                    try {
                        ByteBuffer buffer = ByteBuffer.allocate(512);
                        buffer.order(ByteOrder.BIG_ENDIAN);
                        p.read(0, buffer);
                        byte[] setor = buffer.array();

                        StringBuilder hex = new StringBuilder();
                        for (int b = 0; b < 16; b++) hex.append(String.format("%02X ", setor[b]));

                        String magic = new String(setor, 0, 4, "US-ASCII");

                        log("    Primeiros 16 bytes: " + hex);
                        log("    Como texto (4 bytes): \"" + magic + "\"");

                        if ("FATX".equals(magic)) {
                            log("    ✅ Assinatura FATX encontrada logo no início da partição!");
                        } else {
                            log("    ⚠️ Não achei \"FATX\" no início desta partição.\n" +
                                "       Pode ser outra partição do HD (dashboard/sistema), ou o Xbox\n" +
                                "       organiza esse drive em múltiplas partições internas.");
                        }

                        // Se a libaums conseguiu reconhecer isso como FAT32 (log mostra
                        // "Fat32FileSystem" com sucesso), tentamos listar a raiz - só leitura.
                        try {
                            me.jahnen.libaums.core.fs.FileSystem fs = p.getFileSystem();
                            if (fs != null) {
                                log("    📁 Sistema de arquivos FAT32 reconhecido pela libaums!");
                                me.jahnen.libaums.core.fs.UsbFile root = fs.getRootDirectory();
                                me.jahnen.libaums.core.fs.UsbFile[] filhos = root.listFiles();
                                log("    Conteúdo da raiz (" + filhos.length + " item(ns)):");
                                for (me.jahnen.libaums.core.fs.UsbFile f : filhos) {
                                    log("      " + (f.isDirectory() ? "[PASTA] " : "[arquivo] ") + f.getName());
                                }
                            }
                        } catch (Exception e) {
                            log("    (Não consegui listar como FAT32: " + e + ")");
                        }
                    } catch (Exception e) {
                        log("    Erro ao ler o setor 0 desta partição: " + e);
                    }
                }

                device.close();
                log("");
            } catch (Exception e) {
                log("  Erro ao inicializar o dispositivo: " + e);
            }
        }).start();
    }
}
