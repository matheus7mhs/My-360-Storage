package mhs.usb.meuxbox;

public class ListarGames {
    private String titleId;
    private String nome;
    private String coverUrl;
    private String caminhoLocal;
    private String tipoConteudoHex; // ex: "00000002" p/ DLC, null quando não se aplica (XEX ou o próprio jogo)
    private boolean extra; // true = entrada de DLC/Save/Update, false = jogo/app principal
    private long tamanhoBytes = -1L; // tamanho no USB; -1 enquanto ainda não calculado

    public ListarGames(String titleId, String nome, String caminhoLocal) {
        this(titleId, nome, caminhoLocal, null, false);
    }

    public ListarGames(String titleId, String nome, String caminhoLocal, String tipoConteudoHex, boolean extra) {
        this.titleId = titleId;
        this.nome = nome;
        this.caminhoLocal = caminhoLocal;
        this.tipoConteudoHex = tipoConteudoHex;
        this.extra = extra;
        // Gera a URL da capa automaticamente baseada no TitleID
        this.coverUrl = "https://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId;
    }

    public String getTitleId() { return titleId; }
    public String getNome() { return nome; }
    public String getCoverUrl() { return coverUrl; }
    public String getCaminhoLocal() { return caminhoLocal; }
    public String getTipoConteudoHex() { return tipoConteudoHex; }
    public boolean isExtra() { return extra; }
    public long getTamanhoBytes() { return tamanhoBytes; }
    public void setTamanhoBytes(long tamanhoBytes) { this.tamanhoBytes = tamanhoBytes; }

    /** true quando o caminho aponta para dentro de Content/ (formato GOD/STFS), false para Games/Apps (XEX). */
    public boolean isFormatoGod() {
        return caminhoLocal != null && caminhoLocal.startsWith("Content/");
    }
}
