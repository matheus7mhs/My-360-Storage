package mhs.usb.meuxbox;

import android.content.Context;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * Gerenciador de tema do app.
 *
 * O tema é AUTOMÁTICO: o app segue o modo claro/escuro configurado no celular.
 * Quando o usuário muda o modo do dispositivo (Ajustes → Tela → Tema escuro/claro),
 * o Android troca entre as cores de values/ (tema branco) e values-night/
 * (tema preto, estilo dashboard Xbox 360) automaticamente.
 *
 * - AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM: padrão do app; segue o sistema.
 * - isModoClaro(): usado pelo tutorial HTML para servir a versão clara da página.
 */
public final class ThemeManager {

    private ThemeManager() {
    }

    /**
     * Aplica a política de tema do app: seguir o modo do celular.
     * Deve ser chamado ANTES de setContentView() em cada Activity.
     */
    public static void restaurar(Context context) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }

    /**
     * Informa se o modo atualmente ativo é o CLARO (tema branco).
     * Útil para o WebView do tutorial servir a versão clara do HTML
     * (?tema=branco na URL).
     */
    public static boolean isModoClaro(Context context) {
        int uiMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        return uiMode != Configuration.UI_MODE_NIGHT_YES;
    }
}
