package mhs.usb.meuxbox;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    public interface ActionListener {
        void onVerExtras(ListarGames game);
        void onDesinstalarJogoInteiro(ListarGames game);
        /** Retorna a lista de extras (DLCs, saves, updates) cadastrados no catálogo. */
        List<ListarGames> onGetExtrasList();
    }

    private Context context;
    private List<ListarGames> gamesList;
    private ActionListener listener;

    // Compartilhados entre todas as instâncias do adapter (evita criar um pool de threads novo
    // toda vez que a tela "Meus Jogos" é reaberta, e mantém as imagens já decodificadas em memória
    // entre uma rolagem e outra da lista, sem precisar reler do disco toda hora).
    private static final ExecutorService executor = Executors.newFixedThreadPool(4);
    private static final LruCache<String, Bitmap> memoryCache;
    static {
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8); // 1/8 da memória disponível
        memoryCache = new LruCache<String, Bitmap>(maxKb) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
    }

    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public GameAdapter(Context context, List<ListarGames> gamesList) {
        this(context, gamesList, null);
    }

    public GameAdapter(Context context, List<ListarGames> gamesList, ActionListener listener) {
        this.context = context;
        this.gamesList = gamesList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        ListarGames game = gamesList.get(position);
        
        holder.tvName.setText(game.getNome());
        holder.tvTitleId.setText(game.getTitleId());
        if (game.getTamanhoBytes() >= 0) {
            holder.tvSize.setVisibility(View.VISIBLE);
            holder.tvSize.setText(context.getString(R.string.label_tamanho_jogo_fmt,
                    formatarBytesAmigavel(game.getTamanhoBytes())));
        } else {
            holder.tvSize.setVisibility(View.VISIBLE);
            holder.tvSize.setText(R.string.label_tamanho_calculando);
        }
        
        holder.imgCover.setTag(game.getTitleId());
        // Limpa a imagem anterior para não bugar ao rolar a lista rápido
        holder.imgCover.setImageBitmap(null); 

        // Download do ícone quadrado (XboxUnity) - Passando o ProgressBar da lista
        carregarImagemComCache(game.getTitleId(), game.getCoverUrl(), holder.imgCover, holder.progressLoad);

        holder.itemView.setOnClickListener(v -> abrirDialogoDetalhes(game));
    }

    @Override
    public int getItemCount() {
        return gamesList.size();
    }

    private void abrirDialogoDetalhes(ListarGames game) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_detalhes);
        
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        
        // Largura responsiva: 90% da tela no celular, limitada a ~520 dp em telas grandes.
        int width = ScreenUtils.larguraDialogoPx(context);
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        ImageView imgCover = dialog.findViewById(R.id.dialog_cover);
        ProgressBar progDialog = dialog.findViewById(R.id.dialog_progress);
        TextView tvName = dialog.findViewById(R.id.dialog_name);
        TextView tvTid = dialog.findViewById(R.id.dialog_tid);
        TextView tvPath = dialog.findViewById(R.id.dialog_path);
        TextView tvTamanhoTotal = dialog.findViewById(R.id.dialog_tamanho_total);
        TextView tvDetalheTamanho = dialog.findViewById(R.id.dialog_detalhe_tamanho);
        Button btnClose = dialog.findViewById(R.id.btn_close_dialog);
        Button btnVerExtras = dialog.findViewById(R.id.btn_ver_extras);
        Button btnDesinstalar = dialog.findViewById(R.id.btn_desinstalar);

        tvName.setText(game.getNome());
        tvTid.setText(context.getString(R.string.label_title_id_fmt, game.getTitleId()));
        tvPath.setText(game.getCaminhoLocal());

        // "Ver DLC/Saves/Updates" só faz sentido a partir de um jogo principal (não de um
        // item que já É um DLC/save/update) e só para conteúdo em formato GOD (Content/...).
        if (btnVerExtras != null) {
            boolean mostrarVerExtras = !game.isExtra() && game.isFormatoGod() && listener != null;
            btnVerExtras.setVisibility(mostrarVerExtras ? View.VISIBLE : View.GONE);
            btnVerExtras.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onVerExtras(game);
            });
        }

        if (btnDesinstalar != null) {
            btnDesinstalar.setVisibility(listener != null ? View.VISIBLE : View.GONE);
            btnDesinstalar.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onDesinstalarJogoInteiro(game);
            });
        }

        // ============ TAMANHO TOTAL DO JOGO ============
        // Soma do conteúdo principal + DLCs, saves e updates do mesmo Title ID.
        exibirTamanhoTotal(tvTamanhoTotal, tvDetalheTamanho, game);

        // LINK DE NÍVEL 2: Pasta do TitleID no Archive.org
        String urlPastaId = "https://archive.org/download/xboxunity-covers-fulldump_202311/xboxunity-covers-fulldump/" + game.getTitleId() + "/";
        
        imgCover.setTag(game.getTitleId() + "_cover"); 
        // Chama o cache passando o ProgressBar da janela de detalhes
        carregarImagemComCache(game.getTitleId() + "_cover", urlPastaId, imgCover, progDialog);

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    /**
     * Mostra o tamanho total do jogo no diálogo de detalhes.
     * O tamanho principal (arquivos de jogos/pacotes GOD) é calculado imediatamente em
     * background; os extras (DLC/save/update) só entram na conta quando o app estiver
     * conectado ao drive USB do Xbox (caso contrário mostra apenas o principal).
     */
    private void exibirTamanhoTotal(TextView tvTamanho, TextView tvDetalhe, ListarGames game) {
        tvTamanho.setText(R.string.status_aguardando_analise);
        tvDetalhe.setVisibility(View.GONE);

        UsbXboxConnection conn = UsbXboxConnection.getInstance();
        boolean conectado = conn.isConnected();

        // Extras do MESMO Title ID (só faz sentido contar para jogo em formato GOD, que é
        // onde vivem as DLCs/saves/updates do Xbox 360 no Content/0000000000000000/<TID>/).
        final List<ListarGames> extrasDoJogo;
        if (listener != null && game.isFormatoGod()) {
            extrasDoJogo = new java.util.ArrayList<>();
            List<ListarGames> todosExtras = listener.onGetExtrasList();
            if (todosExtras != null) {
                for (ListarGames e : todosExtras) {
                    if (e.getTitleId().equalsIgnoreCase(game.getTitleId())) extrasDoJogo.add(e);
                }
            }
        } else {
            extrasDoJogo = java.util.Collections.emptyList();
        }

        executor.execute(() -> {
            long totalBytes = 0;
            long principalBytes = calcularTamanhoArquivos(game.getCaminhoLocal(), conn, conectado);
            totalBytes += principalBytes;

            StringBuilder nomeExtras = new StringBuilder();
            for (ListarGames extra : extrasDoJogo) {
                long tamanhoExtra = calcularTamanhoArquivos(extra.getCaminhoLocal(), conn, conectado);
                totalBytes += tamanhoExtra;
                if (nomeExtras.length() > 0) nomeExtras.append(", ");
                nomeExtras.append(extra.getNome());
            }

            final long finalTotal = totalBytes;
            final long finalPrincipal = principalBytes;
            final long totalExtrasBytes = totalBytes - principalBytes;
            final String resumoExtras = nomeExtras.toString();

            runOnUiThread(() -> {
                if (finalTotal > 0) {
                    tvTamanho.setText(String.format(context.getString(R.string.label_tamanho_total_fmt), bytesParaGb(finalTotal)));
                } else if (!conectado) {
                    tvTamanho.setText(R.string.status_aguardando);
                } else {
                    tvTamanho.setText(String.format(context.getString(R.string.label_tamanho_total_fmt), 0.0));
                }

                if (finalPrincipal > 0 && !extrasDoJogo.isEmpty()) {
                    tvDetalhe.setText(context.getString(R.string.label_detalhe_tamanho_fmt,
                            formatarBytes(finalPrincipal), formatarBytes(totalExtrasBytes)));
                    tvDetalhe.setVisibility(View.VISIBLE);
                } else if (!conectado && game.isFormatoGod()) {
                    tvDetalhe.setText(R.string.label_detalhe_tamanho_so_principal);
                    tvDetalhe.setVisibility(View.VISIBLE);
                } else if (!extrasDoJogo.isEmpty()) {
                    tvDetalhe.setText(resumoExtras.isEmpty() ? "" : resumoExtras);
                    tvDetalhe.setVisibility(View.VISIBLE);
                } else {
                    tvDetalhe.setVisibility(View.GONE);
                }
            });
        });
    }

    /**
     * Soma o tamanho (em bytes) dos arquivos de um caminho do drive USB do Xbox.
     * Para GOD (Content/...), soma todos os arquivos da pasta de conteúdo; para XEX,
     * soma todos os arquivos da pasta do jogo (recursivo).
     */
    private long calcularTamanhoArquivos(String caminhoLocal, UsbXboxConnection conn, boolean conectado) {
        if (!conectado || caminhoLocal == null || caminhoLocal.isEmpty()) return 0;
        try {
            me.jahnen.libaums.core.fs.UsbFile file = conn.resolverCaminho(caminhoLocal);
            if (file == null) return 0;
            if (file.isDirectory()) {
                return somarTamanhoRecursivo(file);
            }
            return file.getLength();
        } catch (Exception e) {
            return 0;
        }
    }

    private long somarTamanhoRecursivo(me.jahnen.libaums.core.fs.UsbFile dir) {
        long total = 0;
        try {
            me.jahnen.libaums.core.fs.UsbFile[] children = dir.listFiles();
            if (children == null) return 0;
            for (me.jahnen.libaums.core.fs.UsbFile child : children) {
                if (child.isDirectory()) {
                    total += somarTamanhoRecursivo(child);
                } else {
                    total += child.getLength();
                }
            }
        } catch (Exception e) {
            // Falha de leitura pontual não impede de mostrar o que já foi somado.
        }
        return total;
    }

    private static double bytesParaGb(long bytes) {
        return bytes / (1024.0 * 1024.0 * 1024.0);
    }

    private String formatarBytes(long bytes) {
        if (bytes >= 1024L * 1024 * 1024) {
            return String.format(context.getString(R.string.label_tamanho_total_fmt), bytesParaGb(bytes));
        }
        return String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private void runOnUiThread(Runnable runnable) {
        if (mainHandler != null && Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(runnable);
        } else {
            runnable.run();
        }
    }

    // Método de cache atualizado para receber e controlar o ProgressBar
    private void carregarImagemComCache(String titleId, String urlStr, ImageView imageView, ProgressBar progressBar) {
        // 1. CACHE EM MEMÓRIA - mais rápido possível, sem tocar em disco nem em threads
        Bitmap emMemoria = memoryCache.get(titleId);
        if (emMemoria != null) {
            imageView.setImageBitmap(emMemoria);
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            return;
        }

        File cacheDir = new File(context.getCacheDir(), "xbox_covers");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        
        File imageFile = new File(cacheDir, titleId + ".jpg");

        // 2. CACHE EM DISCO - Se já tem a imagem, esconde o loading e mostra na hora
        if (imageFile.exists() && imageFile.length() > 500) {
            if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            executor.execute(() -> {
                Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                if (bitmap != null) memoryCache.put(titleId, bitmap);
                mainHandler.post(() -> {
                    if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                        imageView.setImageBitmap(bitmap);
                    }
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                });
            });
            return;
        }

        // Se não tem no cache, ativa o loading e vai buscar na internet
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                boolean sucesso = false;

                // LÓGICA DE RASPAGEM PARA O ARCHIVE.ORG (CAPAS GRANDES)
                if (urlStr.contains("archive.org")) {
                    connection = (HttpURLConnection) new URL(urlStr).openConnection();
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    connection.setConnectTimeout(10000);

                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        InputStream inHtml = connection.getInputStream();
                        Scanner scanner = new Scanner(inHtml).useDelimiter("\\A");
                        String html = scanner.hasNext() ? scanner.next() : "";
                        inHtml.close();
                        connection.disconnect();

                        String variante = null;
                        String[] tags = html.split("<a href=\"");
                        for (int i = 1; i < tags.length; i++) {
                            String link = tags[i].split("\"")[0];
                            if (link.endsWith("/") && !link.equals("../")) {
                                variante = link;
                                break;
                            }
                        }

                        if (variante != null) {
                            String[] nomesImagens = {"boxart.png", "front.png", "boxarte.png"};
                            for (String nome : nomesImagens) {
                                String urlFinal = urlStr + variante + nome;
                                
                                connection = (HttpURLConnection) new URL(urlFinal).openConnection();
                                connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                                connection.setInstanceFollowRedirects(true);
                                
                                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    InputStream input = connection.getInputStream();
                                    FileOutputStream output = new FileOutputStream(imageFile);
                                    byte[] buffer = new byte[4096];
                                    int read;
                                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                                    output.close();
                                    input.close();
                                    
                                    if (imageFile.length() > 500) {
                                        sucesso = true;
                                        break; 
                                    }
                                }
                                connection.disconnect();
                            }
                        }
                    }
                } 
                // LÓGICA PADRÃO PARA ÍCONES (XBOX UNITY)
                else {
                    connection = (HttpURLConnection) new URL(urlStr.replace("http://", "https://")).openConnection();
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    connection.setInstanceFollowRedirects(true);
                    
                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        InputStream input = connection.getInputStream();
                        FileOutputStream output = new FileOutputStream(imageFile);
                        byte[] buffer = new byte[4096];
                        int read;
                        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                        output.close();
                        input.close();
                        if (imageFile.length() > 500) sucesso = true;
                    }
                }

                // Carrega a imagem baixada (já reduzida) e DESLIGA o loading
                if (sucesso) {
                    final Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                    if (bitmap != null) memoryCache.put(titleId, bitmap);
                    mainHandler.post(() -> {
                        if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                            imageView.setImageBitmap(bitmap);
                        }
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                    });
                }

            } catch (Exception e) {
                if (imageFile.exists()) imageFile.delete();
                e.printStackTrace();
                mainHandler.post(() -> {
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    /**
     * Decodifica um arquivo de imagem já reduzido para aproximadamente targetW x targetH,
     * em vez de carregar a imagem inteira em resolução original. Isso evita gastar memória e
     * tempo de CPU decodificando capas grandes (o Archive.org entrega imagens de capa que podem
     * ter mais de 1000px de largura) para caber num ícone pequeno de lista.
     */
    private Bitmap decodificarReduzido(String path, int targetW, int targetH) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);

            int sampleSize = 1;
            int largura = bounds.outWidth, altura = bounds.outHeight;
            while ((largura / (sampleSize * 2)) >= targetW && (altura / (sampleSize * 2)) >= targetH) {
                sampleSize *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            return BitmapFactory.decodeFile(path, options);
        } catch (Exception e) {
            return null;
        }
    }

    private String formatarBytesAmigavel(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(java.util.Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(java.util.Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        TextView tvName, tvTitleId, tvSize;
        ProgressBar progressLoad; // Referência para o ProgressBar da lista

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.img_cover);
            tvName = itemView.findViewById(R.id.tv_game_name);
            tvTitleId = itemView.findViewById(R.id.tv_title_id);
            tvSize = itemView.findViewById(R.id.tv_game_size);
            progressLoad = itemView.findViewById(R.id.progress_load);
        }
    }
}
