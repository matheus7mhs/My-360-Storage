package mhs.usb.meuxbox;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class GameDatabase {

    private static final Map<String, String> dbJogos = new HashMap<>();
    private static boolean isLoaded = false;
    private static Context appContext;

    public static void inicializar(Context context) {
        appContext = context.getApplicationContext();
        if (isLoaded) return; 

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(context.getAssets().open("jogos.csv")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                // O split(",") separa o ID do Nome
                String[] parts = line.split(",", 2); 
                
                if (parts.length == 2) {
                    String id = parts[0].trim().toUpperCase();
                    String nome = parts[1].trim();
                    dbJogos.put(id, nome);
                }
            }
            isLoaded = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getNomeDoJogo(String titleId) {
        if (titleId == null) {
            return appContext != null ? appContext.getString(R.string.unknown_game) : "Unknown";
        }
        String idFormatado = titleId.toUpperCase();
        
        if (dbJogos.containsKey(idFormatado)) {
            return dbJogos.get(idFormatado);
        }
        return appContext != null ? appContext.getString(R.string.label_id_fmt, idFormatado) : idFormatado;
    }
}
