package mhs.usb.meuxbox;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import me.jahnen.libaums.core.fs.UsbFile;
import me.jahnen.libaums.core.fs.UsbFileInputStream;

/**
 * Lê o cabeçalho de um pacote STFS (CON/LIVE/PIRS) -- o formato usado por DLC, Saves,
 * Updates (Installer) e os próprios jogos em GOD -- para extrair informações extras além
 * do Title ID/tipo de conteúdo (que já vêm da estrutura de pastas). Offsets conforme a
 * documentação oficial do formato (Free60 Wiki - System-Software/Formats/STFS).
 *
 * Objetivo aqui é só dar um nome mais útil pro usuário na lista de "DLC/Saves/Updates"
 * (ex: qual DLC exatamente, ou de qual perfil é aquele save) -- não uma leitura completa
 * do pacote. Qualquer falha de parsing retorna null/valores vazios em vez de derrubar o
 * escaneamento; um pacote com nome genérico ainda é melhor que a tela travar.
 */
public class StfsParser {

    private static final int OFFSET_PROFILE_ID = 0x371;   // 8 bytes
    private static final int OFFSET_DISPLAY_NAME = 0x411; // 9 blocos de 0x100 bytes (1 por idioma)
    private static final int DISPLAY_NAME_BLOCK_SIZE = 0x100;
    private static final int DISPLAY_NAME_NUM_BLOCOS = 9;
    private static final int TAMANHO_LEITURA = OFFSET_DISPLAY_NAME + (DISPLAY_NAME_BLOCK_SIZE * DISPLAY_NAME_NUM_BLOCOS);

    public static class StfsInfo {
        public final String displayName; // pode ser null se o pacote não tiver/não foi possível ler
        public final String profileIdHex; // 16 chars hex, pode ser null

        StfsInfo(String displayName, String profileIdHex) {
            this.displayName = displayName;
            this.profileIdHex = profileIdHex;
        }
    }

    /** Lê as infos de um pacote STFS já no drive do Xbox (via libaums). Nunca lança exceção. */
    public static StfsInfo ler(UsbFile arquivo) {
        if (arquivo == null || arquivo.isDirectory()) return null;
        try (InputStream is = new UsbFileInputStream(arquivo)) {
            return lerDoStream(is);
        } catch (Exception e) {
            return null;
        }
    }

    private static StfsInfo lerDoStream(InputStream is) throws IOException {
        byte[] header = new byte[TAMANHO_LEITURA];
        int lido = lerExatamente(is, header);
        if (lido < 0x400) return null; // nem o básico do cabeçalho conseguiu ler

        // Confere a magic -- só continua se for realmente um pacote STFS conhecido
        String magic = new String(header, 0, 4, StandardCharsets.US_ASCII);
        if (!magic.equals("CON ") && !magic.equals("LIVE") && !magic.equals("PIRS")) {
            return null;
        }

        String profileIdHex = null;
        if (lido >= OFFSET_PROFILE_ID + 8) {
            StringBuilder sb = new StringBuilder(16);
            for (int i = 0; i < 8; i++) {
                sb.append(String.format("%02X", header[OFFSET_PROFILE_ID + i]));
            }
            profileIdHex = sb.toString();
            // Profile ID zerado = não associado a um perfil específico (comum em DLC/updates)
            if (profileIdHex.matches("^0+$")) profileIdHex = null;
        }

        String displayName = null;
        Charset utf16be = Charset.forName("UTF-16BE");
        for (int bloco = 0; bloco < DISPLAY_NAME_NUM_BLOCOS; bloco++) {
            int offset = OFFSET_DISPLAY_NAME + (bloco * DISPLAY_NAME_BLOCK_SIZE);
            if (lido < offset + DISPLAY_NAME_BLOCK_SIZE) break;
            String texto = new String(header, offset, DISPLAY_NAME_BLOCK_SIZE, utf16be);
            // Corta no primeiro caractere nulo (o campo é preenchido com \0 depois do texto)
            int nulPos = texto.indexOf('\0');
            if (nulPos >= 0) texto = texto.substring(0, nulPos);
            texto = texto.trim();
            if (!texto.isEmpty()) {
                displayName = texto;
                break; // pega o primeiro idioma preenchido (quase sempre o índice 0/inglês)
            }
        }

        if (displayName == null && profileIdHex == null) return null;
        return new StfsInfo(displayName, profileIdHex);
    }

    private static int lerExatamente(InputStream is, byte[] buffer) throws IOException {
        int lido = 0;
        while (lido < buffer.length) {
            int r = is.read(buffer, lido, buffer.length - lido);
            if (r == -1) break;
            lido += r;
        }
        return lido;
    }
}
