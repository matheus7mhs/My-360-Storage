package mhs.usb.meuxbox;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import me.jahnen.libaums.core.fs.UsbFile;
import me.jahnen.libaums.core.fs.UsbFileOutputStream;

public class MeusJogosFragment extends Fragment implements GameAdapter.ActionListener {

    private static final String TIPO_SAVE = "00000001";
    private static final String TIPO_DLC = "00000002";
    private static final String TIPO_UPDATE = "000B0000";

    private RecyclerView recyclerGames;
    private GameAdapter gameAdapter;
    private GameAdapter extrasAdapter;
    private List<ListarGames> gamesList;
    private List<ListarGames> extrasList;      // todos os DLC/save/update encontrados
    private List<ListarGames> extrasExibidos;  // versão filtrada (ou igual a extrasList, sem filtro)
    private Button btnScan;
    private TextView tvStatus;
    private TabLayout tabs;

    // ============ Painel de catálogo ============
    private LinearLayout painelCatalogo;
    private TextView tvCatalogoJogos;
    private TextView tvCatalogoExtras;
    private TextView tvCatalogoEspaco;

    private int abaAtual = 0; // 0 = jogos, 1 = extras
    private String filtroTitleId = null;
    private String filtroNomeJogo = null;
    private boolean proximaSelecaoEhViaFiltro = false;

    private void runOnUi(Runnable r) {
        FragmentActivity act = getActivity();
        if (act == null || !isAdded()) return;
        act.runOnUiThread(() -> {
            if (isAdded() && getActivity() != null) {
                r.run();
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_meus_jogos, container, false);

        recyclerGames = view.findViewById(R.id.recycler_games);
        btnScan = view.findViewById(R.id.btn_scan_games);
        tvStatus = view.findViewById(R.id.tv_scan_status);
        tabs = view.findViewById(R.id.tabs_meus_jogos);
        painelCatalogo = view.findViewById(R.id.painel_catalogo);
        tvCatalogoJogos = view.findViewById(R.id.tv_catalogo_jogos);
        tvCatalogoExtras = view.findViewById(R.id.tv_catalogo_extras);
        tvCatalogoEspaco = view.findViewById(R.id.tv_catalogo_espaco);

        // Grade responsiva: colunas conforme a largura de tela (celular → desktop).
        recyclerGames.setLayoutManager(new GridLayoutManager(getContext(), ScreenUtils.spanCount(requireContext())));
        gamesList = new ArrayList<>();
        extrasList = new ArrayList<>();
        extrasExibidos = new ArrayList<>();
        gameAdapter = new GameAdapter(getContext(), gamesList, this);
        extrasAdapter = new GameAdapter(getContext(), extrasExibidos, this);
        recyclerGames.setAdapter(gameAdapter);

        btnScan.setOnClickListener(v -> conectarEEscanear());

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                abaAtual = tab.getPosition();
                if (abaAtual == 1 && !proximaSelecaoEhViaFiltro) {
                    // Usuário tocou na aba manualmente -- mostra tudo, sem filtro de jogo específico.
                    limparFiltro();
                }
                proximaSelecaoEhViaFiltro = false;
                atualizarAdapterVisivel();
            }

            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        conectarEEscanear();

        return view;
    }

    private void atualizarAdapterVisivel() {
        if (abaAtual == 0) {
            recyclerGames.setAdapter(gameAdapter);
            atualizarStatusPadrao();
        } else {
            recyclerGames.setAdapter(extrasAdapter);
            if (filtroTitleId != null) {
                tvStatus.setText(getString(R.string.label_filtrando_extras_fmt, filtroNomeJogo));
            } else {
                atualizarStatusPadrao();
            }
        }
    }

    private void atualizarStatusPadrao() {
        tvStatus.setText(getString(R.string.status_finalizado_jogos_fmt, gamesList.size()));
    }

    private void limparFiltro() {
        filtroTitleId = null;
        filtroNomeJogo = null;
        extrasExibidos.clear();
        extrasExibidos.addAll(extrasList);
        extrasAdapter.notifyDataSetChanged();
    }

    private void aplicarFiltro(String titleId, String nomeJogo) {
        filtroTitleId = titleId;
        filtroNomeJogo = nomeJogo;
        extrasExibidos.clear();
        for (ListarGames g : extrasList) {
            if (titleId.equalsIgnoreCase(g.getTitleId())) extrasExibidos.add(g);
        }
        extrasAdapter.notifyDataSetChanged();
    }

    // ==================== GameAdapter.ActionListener ====================

    @Override
    public void onVerExtras(ListarGames game) {
        proximaSelecaoEhViaFiltro = true;
        aplicarFiltro(game.getTitleId(), game.getNome());
        if (tabs != null) {
            TabLayout.Tab tab = tabs.getTabAt(1);
            if (tab != null) tab.select();
        }
        if (extrasExibidos.isEmpty()) {
            Toast.makeText(getContext(), R.string.toast_nenhum_extra_encontrado, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public List<ListarGames> onGetExtrasList() {
        // Lista de extras (DLCs, saves, updates) do catálogo, usada pelo adapter para
        // calcular o tamanho total do jogo (jogo + extras do mesmo Title ID).
        return extrasList;
    }

    @Override
    public void onDesinstalarJogoInteiro(ListarGames game) {
        if (game.isExtra()) {
            confirmarApagarItemUnico(game);
        } else if (game.isFormatoGod()) {
            mostrarEscolhaDesinstalarGod(game);
        } else {
            confirmarApagarItemUnico(game);
        }
    }

    private void mostrarEscolhaDesinstalarGod(ListarGames game) {
        String[] opcoes = {
                getString(R.string.opcao_apagar_so_jogo),
                getString(R.string.opcao_apagar_tudo)
        };
        new AlertDialog.Builder(requireContext())
                .setTitle(game.getNome())
                .setItems(opcoes, (dialog, which) -> {
                    if (which == 0) {
                        confirmarApagarCaminho(game.getCaminhoLocal(),
                                getString(R.string.confirmar_apagar_so_jogo_fmt, game.getNome()));
                    } else {
                        String caminhoTid = "Content/0000000000000000/" + game.getTitleId();
                        confirmarApagarCaminho(caminhoTid,
                                getString(R.string.confirmar_apagar_tudo_fmt, game.getNome()));
                    }
                })
                .show();
    }

    private void confirmarApagarItemUnico(ListarGames item) {
        confirmarApagarCaminho(item.getCaminhoLocal(),
                getString(R.string.confirmar_apagar_item_fmt, item.getNome()));
    }

    private void confirmarApagarCaminho(String caminho, String mensagem) {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.dialog_confirmar_exclusao_title)
                .setMessage(mensagem)
                .setPositiveButton(R.string.action_apagar, (dialog, which) -> executarExclusao(caminho))
                .setNegativeButton(R.string.action_cancelar, null)
                .show();
    }

    private void executarExclusao(String caminho) {
        UsbXboxConnection conn = UsbXboxConnection.getInstance();
        if (!conn.isConnected()) {
            Toast.makeText(getContext(), R.string.toast_destino_inacessivel, Toast.LENGTH_SHORT).show();
            return;
        }

        tvStatus.setText(R.string.status_apagando);
        btnScan.setEnabled(false);

        new Thread(() -> {
            try {
                UsbFile alvo = conn.resolverCaminho(caminho);
                if (alvo == null) {
                    runOnUi(() -> Toast.makeText(getContext(), R.string.toast_item_nao_encontrado, Toast.LENGTH_SHORT).show());
                } else {
                    UsbXboxConnection.deletarRecursivo(alvo);
                    runOnUi(() -> Toast.makeText(getContext(), R.string.toast_apagado_com_sucesso, Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUi(() -> Toast.makeText(getContext(), getString(R.string.toast_erro_apagar_fmt, String.valueOf(e.getMessage())), Toast.LENGTH_LONG).show());
            } finally {
                // Reescaneia do zero -- mais simples e seguro do que tentar remover só a entrada
                // afetada das duas listas (uma exclusão pode mudar o jogo principal E seus extras).
                runOnUi(this::conectarEEscanear);
            }
        }).start();
    }

    // ==================== Conexão + escaneamento ====================

    private void conectarEEscanear() {
        UsbXboxConnection conn = UsbXboxConnection.getInstance();

        if (conn.isConnected()) {
            escanearDestino(conn);
            return;
        }

        tvStatus.setText(R.string.status_conectando_usb);
        btnScan.setEnabled(false);

        conn.connectAuto(requireContext(), new UsbXboxConnection.ConnectionCallback() {
            @Override
            public void onConnected(String deviceLabel) {
                runOnUi(() -> escanearDestino(conn));
            }

            @Override
            public void onError(String mensagem) {
                runOnUi(() -> {
                    tvStatus.setText(mensagem);
                    btnScan.setEnabled(true);
                    Toast.makeText(getContext(), R.string.toast_configure_destino_primeiro, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void escanearDestino(UsbXboxConnection conn) {
        UsbFile destRoot = conn.isConnected() ? conn.getFileSystem().getRootDirectory() : null;
        if (destRoot == null) {
            Toast.makeText(getContext(), R.string.toast_destino_inacessivel, Toast.LENGTH_SHORT).show();
            btnScan.setEnabled(true);
            return;
        }

        tvStatus.setText(R.string.status_limpando_cache);
        btnScan.setEnabled(false);
        gamesList.clear();
        extrasList.clear();
        extrasExibidos.clear();
        gameAdapter.notifyDataSetChanged();
        extrasAdapter.notifyDataSetChanged();
        // Se havia um filtro ativo antes de reescanear (ex: depois de apagar algo vindo da
        // tela de extras de um jogo específico), ele deixa de fazer sentido -- os dados mudaram.
        filtroTitleId = null;
        filtroNomeJogo = null;

        new Thread(() -> {
            try {
                // ==========================================
                // 1. ESCANEANDO CONTEÚDO STFS (GOD, Arcade/XBLA, DLC, Save, Update...) em
                //    Content/0000000000000000/<TID>/<content type>
                // ==========================================
                runOnUi(() -> tvStatus.setText(R.string.status_varrendo_god));
                UsbFile contentDir = findChildDir(destRoot, "Content");
                if (contentDir != null) {
                    UsbFile pastaZeros = findChildDir(contentDir, "0000000000000000");
                    if (pastaZeros != null) {
                        UsbFile[] titleIdFolders = pastaZeros.listFiles();
                        if (titleIdFolders != null) {
                            for (UsbFile tidDir : titleIdFolders) {
                                if (!tidDir.isDirectory()) continue;
                                String tid = tidDir.getName();
                                if (tid == null || tid.length() != 8 || !tid.matches("^[0-9a-fA-F]+$") || tid.toUpperCase().startsWith("FF")) {
                                    continue;
                                }

                                UsbFile[] pastasContentType = tidDir.listFiles();
                                if (pastasContentType == null) continue;

                                String nome = GameDatabase.getNomeDoJogo(tid);
                                boolean jogoPrincipalAdicionado = false;

                                for (UsbFile ctFolder : pastasContentType) {
                                    if (!ctFolder.isDirectory()) continue;
                                    UsbFile[] arquivos = ctFolder.listFiles();
                                    if (arquivos == null || arquivos.length == 0) continue;

                                    String hexTipo = ctFolder.getName().toUpperCase();

                                    if (isTipoExtra(hexTipo)) {
                                        // Cada ARQUIVO dentro da pasta de content type é um pacote STFS
                                        // separado (um DLC, um save de um perfil, um update...) -- por
                                        // isso escaneamos arquivo por arquivo em vez de tratar a pasta
                                        // inteira como um item só (senão 3 DLCs viravam 1 entrada).
                                        int totalPacotes = 0;
                                        for (UsbFile p : arquivos) if (!p.isDirectory()) totalPacotes++;

                                        int indiceSemNome = 0;
                                        for (UsbFile pacote : arquivos) {
                                            if (pacote.isDirectory()) continue;
                                            String caminhoArquivo = "Content/0000000000000000/" + tid + "/" + ctFolder.getName() + "/" + pacote.getName();
                                            String nomeExtra = montarNomeExtra(nome, hexTipo, pacote, ++indiceSemNome, totalPacotes);
                                            adicionarExtra(new ListarGames(tid.toUpperCase(), nomeExtra, caminhoArquivo, hexTipo, true));
                                        }
                                    } else if (!jogoPrincipalAdicionado) {
                                        // Qualquer content type que não seja Save/DLC/Update é tratado como
                                        // o próprio jogo -- cobre o "00007000" (GOD/Installed Game) usado por
                                        // este app e também variantes (ex: Arcade/XBLA) que usam outro código.
                                        String caminhoCompleto = "Content/0000000000000000/" + tid + "/" + ctFolder.getName();
                                        adicionarJogo(new ListarGames(tid.toUpperCase(), nome, caminhoCompleto, hexTipo, false));
                                        jogoPrincipalAdicionado = true;
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 2. ESCANEANDO JOGOS FORMATO XEX (Games/ e Apps/)
                // ==========================================
                for (String raiz : new String[]{"Games", "Apps"}) {
                    UsbFile raizDir = findChildDir(destRoot, raiz);
                    if (raizDir != null) {
                        varrerPastaXexRecursivo(raizDir, raiz, 0);
                    }
                }

                runOnUi(() -> {
                    atualizarAdapterVisivel();
                    btnScan.setEnabled(true);
                    atualizarCatalogo();
                    calcularTamanhosCatalogo(conn);
                });

            } catch (Exception e) {
                runOnUi(() -> {
                    tvStatus.setText(getString(R.string.status_erro_leitura_fmt, e.getMessage()));
                    btnScan.setEnabled(true);
                });
            }
        }).start();
    }

    /**
     * Monta o nome exibido de um item de DLC/Save/Update lendo o cabeçalho STFS do próprio
     * pacote (campo "Display Name"). Quando o pacote não tem esse campo preenchido (comum em
     * alguns saves), cai num nome genérico com um número pra pelo menos diferenciar itens do
     * mesmo tipo/jogo na lista.
     */
    private String montarNomeExtra(String nomeJogo, String hexTipo, UsbFile pacote, int indice, int totalPacotes) {
        String base = nomeJogo + " — " + labelContentType(hexTipo);
        StfsParser.StfsInfo info = StfsParser.ler(pacote);

        if (info != null && info.displayName != null && !info.displayName.isEmpty()) {
            String nome = base + ": " + info.displayName;
            // Em saves, o nome do save sozinho às vezes se repete entre perfis diferentes --
            // adiciona um pedaço do Profile ID pra deixar claro que são saves distintos.
            if (TIPO_SAVE.equals(hexTipo) && info.profileIdHex != null) {
                nome += " (Perfil ..." + info.profileIdHex.substring(info.profileIdHex.length() - 6) + ")";
            }
            return nome;
        }

        if (TIPO_SAVE.equals(hexTipo) && info != null && info.profileIdHex != null) {
            return base + " (Perfil ..." + info.profileIdHex.substring(info.profileIdHex.length() - 6) + ")";
        }

        // Sem nome nem Profile ID legíveis -- numera só quando há mais de um pacote do mesmo
        // tipo pro mesmo jogo, pra não ficar tudo com o mesmo texto na lista.
        return totalPacotes > 1 ? base + " #" + indice : base;
    }

    private boolean isTipoExtra(String hexTipoMaiusculo) {
        return TIPO_SAVE.equals(hexTipoMaiusculo) || TIPO_DLC.equals(hexTipoMaiusculo) || TIPO_UPDATE.equals(hexTipoMaiusculo);
    }

    private String labelContentType(String hexTipoMaiusculo) {
        if (TIPO_SAVE.equals(hexTipoMaiusculo)) return getString(R.string.tipo_save);
        if (TIPO_DLC.equals(hexTipoMaiusculo)) return getString(R.string.tipo_dlc);
        if (TIPO_UPDATE.equals(hexTipoMaiusculo)) return getString(R.string.tipo_update);
        return getString(R.string.tipo_outro_fmt, hexTipoMaiusculo);
    }

    private void adicionarJogo(ListarGames jogo) {
        // A lista só pode ser alterada na UI thread -- ver explicação detalhada no histórico
        // deste arquivo (bug de concorrência corrigido anteriormente com o RecyclerView).
        runOnUi(() -> {
            gamesList.add(jogo);
            gameAdapter.notifyItemInserted(gamesList.size() - 1);
            atualizarCatalogo();
        });
    }

    private void adicionarExtra(ListarGames extra) {
        runOnUi(() -> {
            extrasList.add(extra);
            if (filtroTitleId == null || filtroTitleId.equalsIgnoreCase(extra.getTitleId())) {
                extrasExibidos.add(extra);
                extrasAdapter.notifyItemInserted(extrasExibidos.size() - 1);
            }
            atualizarCatalogo();
        });
    }

    /**
     * Atualiza o painel de catálogo: contadores de jogos, DLCs, saves e updates
     * mais o espaço total usado no catálogo (jogos + extras).
     */
    private void atualizarCatalogo() {
        if (painelCatalogo == null) return;
        runOnUi(() -> {
            int nDlcs = 0, nSaves = 0, nUpdates = 0;
            for (ListarGames e : extrasList) {
                String tipo = e.getTipoConteudoHex();
                if (TIPO_DLC.equals(tipo)) nDlcs++;
                else if (TIPO_SAVE.equals(tipo)) nSaves++;
                else if (TIPO_UPDATE.equals(tipo)) nUpdates++;
            }
            tvCatalogoJogos.setText(getString(R.string.label_catalogo_jogos_fmt, gamesList.size()));
            tvCatalogoExtras.setText(getString(R.string.label_catalogo_extras_fmt, nDlcs, nSaves, nUpdates));
            long total = 0;
            boolean completo = !gamesList.isEmpty() || !extrasList.isEmpty();
            for (ListarGames g : gamesList) {
                if (g.getTamanhoBytes() >= 0) total += g.getTamanhoBytes(); else completo = false;
            }
            for (ListarGames e : extrasList) {
                if (e.getTamanhoBytes() >= 0) total += e.getTamanhoBytes(); else completo = false;
            }
            tvCatalogoEspaco.setVisibility(View.VISIBLE);
            tvCatalogoEspaco.setText(completo
                    ? getString(R.string.label_catalogo_espaco_fmt, bytesParaGb(total))
                    : getString(R.string.label_catalogo_espaco_calculando));
            painelCatalogo.setVisibility(View.VISIBLE);
        });
    }

    private void calcularTamanhosCatalogo(UsbXboxConnection conn) {
        if (conn == null || !conn.isConnected()) return;
        new Thread(() -> {
            for (ListarGames jogo : gamesList) {
                jogo.setTamanhoBytes(calcularTamanhoArquivos(jogo.getCaminhoLocal(), conn, true));
                runOnUi(() -> gameAdapter.notifyDataSetChanged());
            }
            for (ListarGames extra : extrasList) {
                extra.setTamanhoBytes(calcularTamanhoArquivos(extra.getCaminhoLocal(), conn, true));
                runOnUi(() -> extrasAdapter.notifyDataSetChanged());
            }
            atualizarCatalogo();
        }).start();
    }

    /** Calcula recursivamente o tamanho de um jogo/extra no USB. Deve rodar fora da UI. */
    private long calcularTamanhoArquivos(String caminho, UsbXboxConnection conn, boolean recursivo) {
        if (conn == null || caminho == null || caminho.trim().isEmpty()) return -1L;
        try {
            UsbFile alvo = conn.resolverCaminho(caminho);
            if (alvo == null) return -1L;
            return somarTamanhoUsb(alvo, recursivo);
        } catch (Exception e) {
            return -1L;
        }
    }

    private long somarTamanhoUsb(UsbFile arquivo, boolean recursivo) throws java.io.IOException {
        if (arquivo == null) return 0L;
        if (!arquivo.isDirectory()) return Math.max(0L, arquivo.getLength());
        if (!recursivo) return 0L;
        long total = 0L;
        UsbFile[] filhos = arquivo.listFiles();
        if (filhos != null) {
            for (UsbFile filho : filhos) {
                long tamanho = somarTamanhoUsb(filho, true);
                if (Long.MAX_VALUE - total < tamanho) return Long.MAX_VALUE;
                total += tamanho;
            }
        }
        return total;
    }

    private double bytesParaGb(long bytes) {
        return bytes / (1024.0 * 1024.0 * 1024.0);
    }

    private UsbFile findChildDir(UsbFile parent, String name) throws java.io.IOException {
        if (parent == null) return null;
        UsbFile[] children = parent.listFiles();
        if (children == null) return null;
        for (UsbFile c : children) {
            if (c.isDirectory() && name.equalsIgnoreCase(c.getName())) return c;
        }
        return null;
    }

    private UsbFile findChildFile(UsbFile parent, String name) throws java.io.IOException {
        UsbFile[] children = parent.listFiles();
        if (children == null) return null;
        for (UsbFile c : children) {
            if (!c.isDirectory() && name.equalsIgnoreCase(c.getName())) return c;
        }
        return null;
    }

    private void varrerPastaXexRecursivo(UsbFile dir, String currentPath, int depth) throws java.io.IOException {
        if (depth > 3 || dir == null) return;

        runOnUi(() -> tvStatus.setText(getString(R.string.status_lendo_fmt, currentPath)));

        UsbFile[] files = dir.listFiles();
        if (files == null) return;

        boolean temDefaultXex = false;
        String idMarcador = null;

        for (UsbFile file : files) {
            if (!file.isDirectory() && file.getName() != null) {
                String nome = file.getName().toLowerCase();
                if (nome.equals("default.xex")) {
                    temDefaultXex = true;
                } else if (nome.startsWith("mhs_id_") && nome.endsWith(".txt")) {
                    idMarcador = nome.substring(7, nome.length() - 4).toUpperCase();
                }
            }
        }

        if (temDefaultXex) {
            String nomeJogo;
            String idParaCapa;

            if (idMarcador != null) {
                nomeJogo = GameDatabase.getNomeDoJogo(idMarcador);
                idParaCapa = idMarcador;
            } else {
                runOnUi(() -> tvStatus.setText(R.string.status_catalogando));
                UsbFile defaultXex = findChildFile(dir, "default.xex");
                String idExtraida = defaultXex != null ? XexParser.getTitleId(defaultXex) : null;

                if (idExtraida != null) {
                    try {
                        String marcador = "mhs_id_" + idExtraida + ".txt";
                        UsbFile marcadorFile = dir.createFile(marcador);
                        try (UsbFileOutputStream os = new UsbFileOutputStream(marcadorFile)) {
                            os.write("MHS".getBytes());
                        }
                    } catch (Exception ignored) {}

                    nomeJogo = GameDatabase.getNomeDoJogo(idExtraida);
                    idParaCapa = idExtraida;
                } else {
                    String[] partes = currentPath.split("/");
                    nomeJogo = getString(R.string.game_name_xex_fmt, partes[partes.length - 1]);
                    idParaCapa = "XEX_DESCONHECIDO";
                }
            }

            adicionarJogo(new ListarGames(idParaCapa, nomeJogo, currentPath));
            return;
        }

        for (UsbFile subDir : files) {
            if (subDir.isDirectory() && subDir.getName() != null) {
                varrerPastaXexRecursivo(subDir, currentPath + "/" + subDir.getName(), depth + 1);
            }
        }
    }
}
