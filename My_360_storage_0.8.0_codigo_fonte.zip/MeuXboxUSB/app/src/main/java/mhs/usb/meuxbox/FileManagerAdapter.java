package mhs.usb.meuxbox;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import me.jahnen.libaums.core.fs.UsbFile;

/** Lista os arquivos/pastas de UM nível do drive do Xbox, com suporte a seleção múltipla. */
public class FileManagerAdapter extends RecyclerView.Adapter<FileManagerAdapter.ViewHolder> {

    public interface Listener {
        void onAbrirPasta(UsbFile pasta);
        void onToggleSelecao(UsbFile item);
        void onEntrarModoSelecao(UsbFile item);
    }

    private final List<UsbFile> itens;
    private final Listener listener;
    private final Set<String> selecionados = new HashSet<>(); // por nome (único dentro do mesmo nível)
    private boolean modoSelecao = false;
    private String caminhoDaPastaAtual = null; // ex.: "/Content/0000000000000000" -- usado para rotular TitleIDs
    private boolean dentroDoContent = false;

    public FileManagerAdapter(List<UsbFile> itens, Listener listener) {
        this.itens = itens;
        this.listener = listener;
    }

    /**
     * Informa onde o gerenciador está navegando, para poder mostrar o NOME do jogo
     * em vez do Title ID (números) nas pastas de Content/0000000000000000/XXXX.
     * Usa o nome da pasta atual (0000000000000000) como critério principal, que é
     * mais confiável que o caminho montado para exibição.
     */
    public void setContextoNavegacao(String caminhoExibicao, String nomeDaPastaAtual) {
        boolean mudou = this.dentroDoContent;
        this.caminhoDaPastaAtual = caminhoExibicao;
        boolean peloCaminho = caminhoExibicao != null &&
                caminhoExibicao.toUpperCase(Locale.getDefault()).contains("/CONTENT/0000000000000000/");
        boolean peloNome = nomeDaPastaAtual != null && nomeDaPastaAtual.equalsIgnoreCase("0000000000000000");
        this.dentroDoContent = peloCaminho || peloNome;
        if (mudou != this.dentroDoContent) {
            // Estado mudou -- re-renderiza os itens com os novos rótulos.
            notifyDataSetChanged();
        }
    }

    public void setModoSelecao(boolean ativo) {
        this.modoSelecao = ativo;
        if (!ativo) selecionados.clear();
        notifyDataSetChanged();
    }

    private String tituloDeExibicao(UsbFile item) {
        // Nas pastas do Content/0000000000000000, cada subpasta é um Title ID (ex.: "415607D1").
        // Se estivermos lá dentro, mostra o nome amigável do jogo (banco de dados).
        if (dentroDoContent && item.isDirectory()) {
            String possivelId = item.getName();
            if (possivelId != null && possivelId.matches("[0-9A-Fa-f]{8}")) {
                String nomeDoJogo = GameDatabase.getNomeDoJogo(possivelId.toUpperCase(Locale.getDefault()));
                // O banco retorna "ID: XXXXXXXX" quando o jogo não é encontrado -- nesse
                // caso mostramos o nome original da pasta (o ID numérico mesmo).
                if (nomeDoJogo != null && !nomeDoJogo.toUpperCase(Locale.getDefault()).contains(possivelId.toUpperCase(Locale.getDefault()))) {
                    return nomeDoJogo;
                }
            }
        }
        return item.getName();
    }

    public boolean isModoSelecao() { return modoSelecao; }

    public void limparSelecao() {
        selecionados.clear();
        notifyDataSetChanged();
    }

    public int getQuantidadeSelecionada() { return selecionados.size(); }

    public List<UsbFile> getSelecionados() {
        List<UsbFile> lista = new java.util.ArrayList<>();
        for (UsbFile f : itens) if (selecionados.contains(f.getName())) lista.add(f);
        return lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file_manager, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UsbFile item = itens.get(position);
        boolean isDir = item.isDirectory();
        String nome = item.getName();

        holder.tvNome.setText(tituloDeExibicao(item));
        holder.tvNome.setTooltipText(nome);
        holder.imgIcone.setImageResource(isDir ? R.drawable.ic_folder : android.R.drawable.ic_menu_save);

        if (isDir) {
            // Dentro do Content, mostra o Title ID real embaixo do nome do jogo, para
            // manter a identificação exata da pasta mesmo com o nome amigável.
            if (dentroDoContent && nome != null && nome.matches("[0-9A-Fa-f]{8}")) {
                String formato = holder.itemView.getContext().getString(R.string.label_pasta_id_fmt);
                holder.tvSubtitulo.setText(String.format(Locale.getDefault(), formato, nome.toUpperCase(Locale.getDefault())));
            } else {
                holder.tvSubtitulo.setText(R.string.label_pasta);
            }
        } else {
            holder.tvSubtitulo.setText(formatarTamanho(item.getLength()));
        }

        boolean selecionado = selecionados.contains(nome);
        holder.checkbox.setVisibility(modoSelecao ? View.VISIBLE : View.GONE);
        holder.checkbox.setChecked(selecionado);
        holder.itemView.setSelected(selecionado);

        holder.itemView.setOnClickListener(v -> {
            if (modoSelecao) {
                toggle(nome);
                listener.onToggleSelecao(item);
            } else if (isDir) {
                listener.onAbrirPasta(item);
            } else {
                toggle(nome);
                listener.onEntrarModoSelecao(item);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (!modoSelecao) {
                toggle(nome);
                listener.onEntrarModoSelecao(item);
            } else {
                toggle(nome);
                listener.onToggleSelecao(item);
            }
            return true;
        });

        holder.checkbox.setOnClickListener(v -> {
            toggle(nome);
            listener.onToggleSelecao(item);
        });
    }

    private void toggle(String nome) {
        if (selecionados.contains(nome)) selecionados.remove(nome);
        else selecionados.add(nome);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() { return itens.size(); }

    private static String formatarTamanho(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024));
        return String.format(Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgIcone;
        TextView tvNome, tvSubtitulo;
        CheckBox checkbox;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgIcone = itemView.findViewById(R.id.img_fm_icone);
            tvNome = itemView.findViewById(R.id.tv_fm_nome);
            tvSubtitulo = itemView.findViewById(R.id.tv_fm_subtitulo);
            checkbox = itemView.findViewById(R.id.checkbox_fm_item);
        }
    }
}
