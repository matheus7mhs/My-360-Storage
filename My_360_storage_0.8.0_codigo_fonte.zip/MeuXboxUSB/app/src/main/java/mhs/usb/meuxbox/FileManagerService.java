package mhs.usb.meuxbox;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import me.jahnen.libaums.core.fs.UsbFile;
import me.jahnen.libaums.core.fs.UsbFileInputStream;
import me.jahnen.libaums.core.fs.UsbFileOutputStream;

/**
 * Operações do Gerenciador de Arquivos USB que envolvem cópia de bytes (não apagar --
 * isso continua sendo feito direto na tela, é rápido o bastante pra não precisar de
 * serviço em primeiro plano): copiar/colar DENTRO do drive do Xbox, e fazer backup de
 * arquivos/pastas do drive para o armazenamento do celular (via SAF).
 *
 * Mantém o mesmo espírito de robustez do TransferService (retry por arquivo, WakeLock,
 * notificação de progresso), mas sem a lógica específica de GOD/XEX -- aqui é cópia
 * genérica de arquivos/pastas.
 */
public class FileManagerService extends Service {

    private static final int NOTIF_ID = 1002;
    private static final int BUFFER_SIZE = 64 * 1024;
    private static final int MAX_TENTATIVAS = 3;

    public interface OpListener {
        void onStatus(String status);
        void onProgress(int pct);
        void onFinished(boolean sucesso, String erro, int falhas);
    }

    public class LocalBinder extends Binder {
        FileManagerService getService() { return FileManagerService.this; }
    }

    private final IBinder binder = new LocalBinder();
    private volatile OpListener listener;
    private volatile boolean operacaoEmAndamento = false;

    private NotificationManager notificationManager;
    private NotificationCompat.Builder notificationBuilder;
    private PowerManager.WakeLock wakeLock;

    private long totalBytesGlobal, bytesCopiadosGlobal;
    private int totalArquivos, arquivosOk, arquivosComFalha;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                    new NotificationChannel(TransferService.CHANNEL_ID, getString(R.string.notif_channel_xbox_usb), NotificationManager.IMPORTANCE_LOW));
        }
        notificationBuilder = new NotificationCompat.Builder(this, TransferService.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(getString(R.string.notif_channel_xbox_usb))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true);
        startForeground(NOTIF_ID, notificationBuilder.build());

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MeuXboxUSB:gerenciadorArquivos");
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        liberarWakeLock();
    }

    public boolean isOperacaoEmAndamento() { return operacaoEmAndamento; }

    public void setListener(OpListener l) { this.listener = l; }

    private void postStatus(String s) { OpListener l = listener; if (l != null) l.onStatus(s); }
    private void postProgress(int p) { OpListener l = listener; if (l != null) l.onProgress(p); }

    // ==================== Copiar/colar dentro do drive do Xbox ====================

    public void iniciarCopiaInterna(List<UsbFile> origens, UsbFile pastaDestino) {
        if (operacaoEmAndamento) return;
        operacaoEmAndamento = true;

        new Thread(() -> {
            boolean sucesso = true;
            String erro = null;
            try {
                iniciarNotificacao(getString(R.string.notif_copiando_titulo));
                resetarContadores();
                for (UsbFile origem : origens) somarRecursivo(origem);
                postStatus(getString(R.string.status_preparando_envio));

                for (UsbFile origem : origens) {
                    String nomeDestino = resolverNomeUnicoUsb(pastaDestino, origem.getName());
                    copiarUsbParaUsbRecursivo(origem, pastaDestino, nomeDestino);
                }
            } catch (Exception e) {
                sucesso = false;
                erro = String.valueOf(e.getMessage());
            }
            finalizar(sucesso, erro);
        }).start();
    }

    private void copiarUsbParaUsbRecursivo(UsbFile origem, UsbFile destPai, String nomeDestino) throws IOException {
        if (origem.isDirectory()) {
            UsbFile novaPasta = destPai.createDirectory(nomeDestino);
            UsbFile[] filhos = origem.listFiles();
            if (filhos != null) {
                for (UsbFile filho : filhos) {
                    String nomeFilhoDestino = resolverNomeUnicoUsb(novaPasta, filho.getName());
                    copiarUsbParaUsbRecursivo(filho, novaPasta, nomeFilhoDestino);
                }
            }
        } else {
            copiarArquivoUsbParaUsb(origem, destPai, nomeDestino);
        }
    }

    private void copiarArquivoUsbParaUsb(UsbFile origem, UsbFile destPai, String nomeDestino) throws IOException {
        long tamanho = origem.getLength();
        Exception ultimaExcecao = null;

        for (int tentativa = 1; tentativa <= MAX_TENTATIVAS; tentativa++) {
            try {
                postStatus(getString(R.string.status_copiando_fmt, origem.getName()));
                UsbFile novoArquivo = destPai.createFile(nomeDestino);
                try { novoArquivo.setLength(tamanho); } catch (Exception ignored) {}

                try (InputStream is = new UsbFileInputStream(origem);
                     UsbFileOutputStream os = new UsbFileOutputStream(novoArquivo)) {
                    byte[] buffer = new byte[BUFFER_SIZE];
                    int lidos;
                    while ((lidos = is.read(buffer)) != -1) {
                        os.write(buffer, 0, lidos);
                        bytesCopiadosGlobal += lidos;
                        atualizarProgresso();
                    }
                }
                arquivosOk++;
                return;
            } catch (Exception e) {
                ultimaExcecao = e;
                limparParcialUsb(destPai, nomeDestino);
                if (tentativa < MAX_TENTATIVAS) {
                    try { Thread.sleep(1500L * tentativa); } catch (InterruptedException ignored) {}
                }
            }
        }
        arquivosComFalha++;
        throw new IOException(ultimaExcecao != null ? String.valueOf(ultimaExcecao.getMessage()) : "Erro ao copiar " + origem.getName());
    }

    // ==================== Backup: drive do Xbox -> armazenamento do Android ====================

    public void iniciarBackup(List<UsbFile> origens, DocumentFile pastaDestino) {
        if (operacaoEmAndamento) return;
        operacaoEmAndamento = true;

        new Thread(() -> {
            boolean sucesso = true;
            String erro = null;
            try {
                iniciarNotificacao(getString(R.string.notif_backup_titulo));
                resetarContadores();
                for (UsbFile origem : origens) somarRecursivo(origem);
                postStatus(getString(R.string.status_preparando_envio));

                for (UsbFile origem : origens) {
                    copiarUsbParaAndroidRecursivo(origem, pastaDestino);
                }
            } catch (Exception e) {
                sucesso = false;
                erro = String.valueOf(e.getMessage());
            }
            // Backup parcial (alguns arquivos falharam mas outros foram, ex: nomes com
            // caracteres que o SAF não aceita) ainda conta como sucesso geral -- o usuário
            // vê quantos falharam no resultado final.
            finalizar(sucesso, erro);
        }).start();
    }

    private void copiarUsbParaAndroidRecursivo(UsbFile origem, DocumentFile destPai) {
        try {
            if (origem.isDirectory()) {
                String nomeDestino = resolverNomeUnicoDocumentFile(destPai, origem.getName());
                DocumentFile novaPasta = destPai.createDirectory(nomeDestino);
                if (novaPasta == null) { arquivosComFalha++; return; }
                UsbFile[] filhos = origem.listFiles();
                if (filhos != null) {
                    for (UsbFile filho : filhos) {
                        copiarUsbParaAndroidRecursivo(filho, novaPasta);
                    }
                }
            } else {
                copiarArquivoUsbParaAndroid(origem, destPai);
            }
        } catch (Exception e) {
            arquivosComFalha++;
            // Best effort -- um arquivo/pasta problemático não deve abortar o backup inteiro.
        }
    }

    private void copiarArquivoUsbParaAndroid(UsbFile origem, DocumentFile destPai) throws IOException {
        Exception ultimaExcecao = null;

        for (int tentativa = 1; tentativa <= MAX_TENTATIVAS; tentativa++) {
            try {
                postStatus(getString(R.string.status_copiando_fmt, origem.getName()));
                String nomeDestino = resolverNomeUnicoDocumentFile(destPai, origem.getName());
                DocumentFile novoArquivo = destPai.createFile("application/octet-stream", nomeDestino);
                if (novoArquivo == null) throw new IOException("Não foi possível criar " + nomeDestino);

                try (InputStream is = new UsbFileInputStream(origem);
                     OutputStream os = getContentResolver().openOutputStream(novoArquivo.getUri())) {
                    if (os == null) throw new IOException("Não foi possível abrir destino para " + nomeDestino);
                    byte[] buffer = new byte[BUFFER_SIZE];
                    int lidos;
                    while ((lidos = is.read(buffer)) != -1) {
                        os.write(buffer, 0, lidos);
                        bytesCopiadosGlobal += lidos;
                        atualizarProgresso();
                    }
                }
                arquivosOk++;
                return;
            } catch (Exception e) {
                ultimaExcecao = e;
                if (tentativa < MAX_TENTATIVAS) {
                    try { Thread.sleep(1500L * tentativa); } catch (InterruptedException ignored) {}
                }
            }
        }
        arquivosComFalha++;
        throw new IOException(ultimaExcecao != null ? String.valueOf(ultimaExcecao.getMessage()) : "Erro ao copiar " + origem.getName());
    }

    // ==================== Utilidades compartilhadas ====================

    private void resetarContadores() {
        totalBytesGlobal = 0; bytesCopiadosGlobal = 0;
        totalArquivos = 0; arquivosOk = 0; arquivosComFalha = 0;
    }

    private void somarRecursivo(UsbFile f) {
        try {
            if (f.isDirectory()) {
                UsbFile[] filhos = f.listFiles();
                if (filhos != null) for (UsbFile c : filhos) somarRecursivo(c);
            } else {
                totalBytesGlobal += f.getLength();
                totalArquivos++;
            }
        } catch (Exception ignored) {}
    }

    private String resolverNomeUnicoUsb(UsbFile pastaDestino, String nomeDesejado) {
        try {
            UsbFile[] existentes = pastaDestino.listFiles();
            if (existentes == null) return nomeDesejado;
            return proximoNomeLivre(nomeDesejado, nome -> {
                for (UsbFile e : existentes) if (nome.equalsIgnoreCase(e.getName())) return true;
                return false;
            });
        } catch (Exception e) {
            return nomeDesejado;
        }
    }

    private String resolverNomeUnicoDocumentFile(DocumentFile pastaDestino, String nomeDesejado) {
        DocumentFile[] existentes = pastaDestino.listFiles();
        return proximoNomeLivre(nomeDesejado, nome -> {
            for (DocumentFile e : existentes) if (nome.equalsIgnoreCase(e.getName())) return true;
            return false;
        });
    }

    private interface NomeExisteChecker { boolean existe(String nome); }

    /** Se "nomeDesejado" já existir no destino, tenta "nome (2)", "nome (3)"... até achar um livre. */
    private String proximoNomeLivre(String nomeDesejado, NomeExisteChecker checker) {
        if (!checker.existe(nomeDesejado)) return nomeDesejado;

        String base = nomeDesejado;
        String extensao = "";
        int pontoIdx = nomeDesejado.lastIndexOf('.');
        if (pontoIdx > 0) {
            base = nomeDesejado.substring(0, pontoIdx);
            extensao = nomeDesejado.substring(pontoIdx);
        }

        for (int n = 2; n < 1000; n++) {
            String tentativa = base + " (" + n + ")" + extensao;
            if (!checker.existe(tentativa)) return tentativa;
        }
        return nomeDesejado + "_" + System.currentTimeMillis();
    }

    private void limparParcialUsb(UsbFile pastaDestino, String nomeArquivo) {
        try {
            UsbFile[] filhos = pastaDestino.listFiles();
            if (filhos == null) return;
            for (UsbFile f : filhos) {
                if (!f.isDirectory() && nomeArquivo.equalsIgnoreCase(f.getName())) {
                    f.delete();
                    return;
                }
            }
        } catch (Exception ignored) {}
    }

    private void finalizar(boolean sucesso, String erro) {
        liberarWakeLock();
        finalizarNotificacao(sucesso);
        operacaoEmAndamento = false;
        OpListener l = listener;
        if (l != null) l.onFinished(sucesso, erro, arquivosComFalha);
        stopForeground(STOP_FOREGROUND_DETACH);
        stopSelf();
    }

    private void liberarWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    private long ultimoNotifyMs = 0;
    private int ultimoPctNotificado = -1;

    private void atualizarProgresso() {
        int pct = totalBytesGlobal > 0 ? (int) ((bytesCopiadosGlobal * 100) / totalBytesGlobal) : 0;
        if (pct > 100) pct = 100;
        postProgress(pct);

        long agora = System.currentTimeMillis();
        if (notificationBuilder != null && notificationManager != null
                && pct != ultimoPctNotificado && (agora - ultimoNotifyMs) >= 400) {
            ultimoNotifyMs = agora;
            ultimoPctNotificado = pct;
            notificationBuilder.setProgress(100, pct, false)
                    .setContentText(getString(R.string.notif_total_fmt, pct, arquivosOk, totalArquivos));
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }

    private void iniciarNotificacao(String titulo) {
        ultimoNotifyMs = 0;
        ultimoPctNotificado = -1;
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(30 * 60 * 1000L /*30 min*/); } catch (Exception ignored) {}
        }
        notificationBuilder = new NotificationCompat.Builder(this, TransferService.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(titulo)
                .setContentText(getString(R.string.notif_calculando_tempo))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        notificationManager.notify(NOTIF_ID, notificationBuilder.build());
    }

    private void finalizarNotificacao(boolean sucesso) {
        if (notificationBuilder == null || notificationManager == null) return;
        if (sucesso) {
            notificationBuilder.setContentTitle(getString(R.string.notif_transferencia_concluida_title))
                    .setContentText(getString(R.string.notif_operacao_arquivos_concluida))
                    .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                    .setProgress(0, 0, false)
                    .setOngoing(false);
        } else {
            notificationBuilder.setContentTitle(getString(R.string.notif_erro_title))
                    .setContentText(getString(R.string.notif_operacao_arquivos_falhou))
                    .setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setProgress(0, 0, false)
                    .setOngoing(false);
        }
        notificationManager.notify(NOTIF_ID, notificationBuilder.build());
    }
}
