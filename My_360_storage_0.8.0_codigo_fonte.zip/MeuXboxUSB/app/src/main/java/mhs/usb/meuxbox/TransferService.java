package mhs.usb.meuxbox;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import me.jahnen.libaums.core.fs.UsbFile;
import me.jahnen.libaums.core.fs.UsbFileOutputStream;

/**
 * Copia os arquivos do jogo (selecionados via SAF na pasta do celular) para o pendrive/HD
 * do Xbox 360 conectado via cabo OTG. A ORIGEM é lida pelo SAF normal do Android (arquivo
 * está no armazenamento do próprio celular). O DESTINO é escrito diretamente via libaums
 * (USB Mass Storage bruto), porque o Android não sabe montar esse drive pelo SAF.
 */
public class TransferService extends Service {

    public static final String CHANNEL_ID = "xbox_usb_transfer";
    private static final int NOTIF_ID = 1001;
    private static final int BUFFER_SIZE = 64 * 1024;
    private static final int MAX_TENTATIVAS = 3;

    public interface ProgressListener {
        void onStatus(String status);
        void onFileCount(int done, int total);
        void onProgress(int individualPct, int totalPct);
        void onGameInfo(String gameName, String titleId);
        void onFinished(boolean success, String errorMsg);
    }

    public class LocalBinder extends Binder {
        TransferService getService() { return TransferService.this; }
    }

    private final IBinder binder = new LocalBinder();
    private volatile ProgressListener listener;
    private volatile boolean transferEmAndamento = false;

    private String lastStatus = "";
    private int lastFileDone = 0, lastFileTotal = 0;
    private int lastIndividualPct = 0, lastTotalPct = 0;
    private String lastGameName = null, lastTitleId = null;

    private NotificationManager notificationManager;
    private NotificationCompat.Builder notificationBuilder;
    private PowerManager.WakeLock wakeLock;

    private long totalBytesGlobal = 0;
    private long bytesCopiadosGlobal = 0;
    private int totalArquivos = 0;
    private int arquivosCopiados = 0;

    private static class CopyTask {
        DocumentFile localFile;
        String[] destPath; // caminho completo no drive do Xbox, último item é o nome
        CopyTask(DocumentFile f, String[] p) { localFile = f; destPath = p; }
    }

    private static class ResultadoCopia {
        boolean sucesso;
        String erro;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                    new NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_xbox_usb), NotificationManager.IMPORTANCE_LOW));
        }
        notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(getString(R.string.notif_channel_xbox_usb))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true);
        startForeground(NOTIF_ID, notificationBuilder.build());

        // Mantém a CPU acordada durante a transferência. Em transferências longas via OTG,
        // o Android entrando em estados de economia de energia no meio do caminho é um dos
        // fatores que pode deixar a conexão USB instável -- isso reduz esse risco.
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MeuXboxUSB:transferencia");
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        liberarWakeLock();
    }

    public boolean isTransferEmAndamento() {
        return transferEmAndamento;
    }

    public void setListener(ProgressListener l) {
        this.listener = l;
        if (l != null) {
            l.onGameInfo(lastGameName, lastTitleId);
            l.onStatus(lastStatus);
            l.onFileCount(lastFileDone, lastFileTotal);
            l.onProgress(lastIndividualPct, lastTotalPct);
        }
    }

    private void postStatus(String s) {
        lastStatus = s;
        ProgressListener l = listener;
        if (l != null) l.onStatus(s);
    }

    private void postFileCount(int d, int t) {
        lastFileDone = d; lastFileTotal = t;
        ProgressListener l = listener;
        if (l != null) l.onFileCount(d, t);
    }

    private void postProgress(int i, int t) {
        lastIndividualPct = i; lastTotalPct = t;
        ProgressListener l = listener;
        if (l != null) l.onProgress(i, t);
    }

    private void postGameInfo(String nome, String tid) {
        lastGameName = nome; lastTitleId = tid;
        ProgressListener l = listener;
        if (l != null) l.onGameInfo(nome, tid);
    }

    // ==================== MODO 1: pasta inteira de jogo (GOD ou XEX) ====================

    /**
     * @param rootDir    pasta de origem selecionada no celular (jogo GOD ou XEX), via SAF
     * @param xexDest    "Games" ou "Apps" quando for um jogo XEX solto; null quando for GOD (STFS)
     * @param titleIdMarker título ID descoberto para gravar o arquivo marcador (evita reanalisar depois)
     */
    public void iniciarTransferencia(DocumentFile rootDir, String xexDest,
                                      String titleIdMarker, String nomeFallback) {
        if (transferEmAndamento) return;

        UsbXboxConnection conn = UsbXboxConnection.getInstance();
        if (!conn.isConnected()) {
            ProgressListener l = listener;
            if (l != null) l.onFinished(false, getString(R.string.toast_destino_inacessivel));
            return;
        }
        UsbFile destRoot = conn.getFileSystem().getRootDirectory();

        transferEmAndamento = true;
        resetarContadores();
        postStatus(getString(R.string.status_preparando_envio));

        new Thread(() -> {
            List<CopyTask> tarefas = new ArrayList<>();

            if (xexDest != null) {
                String[] baseRemoto = new String[]{xexDest, rootDir.getName()};
                tarefas.add(new CopyTask(rootDir, baseRemoto));
                mapearRecursivoXEX(rootDir, baseRemoto, tarefas);
            } else {
                analisarPastaSTFS(rootDir, rootDir.getName(), tarefas);
            }

            String nomeParaNotificacao = (lastGameName != null) ? lastGameName : nomeFallback;

            if (tarefas.isEmpty()) {
                finalizarSemArquivos(nomeParaNotificacao);
                return;
            }

            Map<String, UsbFile> dirCache = new HashMap<>();
            ResultadoCopia resultado = executarTarefas(destRoot, tarefas, nomeParaNotificacao, dirCache);

            if (resultado.sucesso && xexDest != null && titleIdMarker != null) {
                try {
                    UsbFile destRootAtual = conn.isConnected() ? conn.getFileSystem().getRootDirectory() : null;
                    if (destRootAtual != null) {
                        UsbFile pastaJogo = resolverOuCriarDir(destRootAtual, new String[]{xexDest, rootDir.getName()}, dirCache);
                        String marcador = "mhs_id_" + titleIdMarker + ".txt";
                        UsbFile existente = findChild(pastaJogo, marcador, false);
                        if (existente == null) {
                            UsbFile marcadorFile = pastaJogo.createFile(marcador);
                            try (UsbFileOutputStream os = new UsbFileOutputStream(marcadorFile)) {
                                os.write("MHS".getBytes());
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }

            concluir(resultado, nomeParaNotificacao);
        }).start();
    }

    // ==================== MODO 2: arquivos avulsos (mídia, plugins, etc.) ====================

    /**
     * Copia uma lista de arquivos soltos (não uma pasta de jogo) para uma subpasta do drive
     * do Xbox. Útil para mídias, plugins, ou qualquer arquivo que não faça parte da estrutura
     * de um jogo GOD/XEX.
     *
     * @param arquivos       arquivos individuais selecionados no celular (via SAF)
     * @param pastaDestino   caminho relativo dentro do drive do Xbox (ex: "Games/MeuApp/Media").
     *                       Use string vazia para copiar direto na raiz do drive.
     */
    public void iniciarTransferenciaArquivosAvulsos(List<DocumentFile> arquivos, String pastaDestino, String nomeFallback) {
        if (transferEmAndamento) return;

        UsbXboxConnection conn = UsbXboxConnection.getInstance();
        if (!conn.isConnected()) {
            ProgressListener l = listener;
            if (l != null) l.onFinished(false, getString(R.string.toast_destino_inacessivel));
            return;
        }
        UsbFile destRoot = conn.getFileSystem().getRootDirectory();

        transferEmAndamento = true;
        resetarContadores();
        postStatus(getString(R.string.status_preparando_envio));

        new Thread(() -> {
            String pastaLimpa = pastaDestino == null ? "" : pastaDestino.trim().replaceAll("^/+|/+$", "");
            String[] baseSegments = pastaLimpa.isEmpty() ? new String[0] : pastaLimpa.split("/+");

            List<CopyTask> tarefas = new ArrayList<>();
            for (DocumentFile f : arquivos) {
                if (f == null || !f.isFile()) continue;
                String[] destPath = appendPath(baseSegments, f.getName());
                tarefas.add(new CopyTask(f, destPath));
                totalArquivos++;
                totalBytesGlobal += f.length();
            }

            String nomeParaNotificacao = nomeFallback;

            if (tarefas.isEmpty()) {
                finalizarSemArquivos(nomeParaNotificacao);
                return;
            }

            Map<String, UsbFile> dirCache = new HashMap<>();
            ResultadoCopia resultado = executarTarefas(destRoot, tarefas, nomeParaNotificacao, dirCache);
            concluir(resultado, nomeParaNotificacao);
        }).start();
    }

    // ==================== Núcleo compartilhado de execução ====================

    private void resetarContadores() {
        totalBytesGlobal = 0;
        bytesCopiadosGlobal = 0;
        totalArquivos = 0;
        arquivosCopiados = 0;
    }

    private void finalizarSemArquivos(String nomeParaNotificacao) {
        postStatus(getString(R.string.status_aguardando));
        transferEmAndamento = false;
        liberarWakeLock();
        ProgressListener l = listener;
        if (l != null) l.onFinished(false, getString(R.string.toast_nenhum_arquivo));
        pararServico();
    }

    private void concluir(ResultadoCopia resultado, String nomeParaNotificacao) {
        liberarWakeLock();
        finalizarNotificacao(nomeParaNotificacao, resultado.sucesso);
        postStatus(resultado.sucesso ? getString(R.string.status_finalizado) : getString(R.string.status_falha_tentativas));
        transferEmAndamento = false;
        ProgressListener l = listener;
        if (l != null) l.onFinished(resultado.sucesso, resultado.sucesso ? null : resultado.erro);
        pararServico();
    }

    private void liberarWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    /**
     * Executa a lista de tarefas com retry por arquivo. IMPORTANTE: só consideramos um arquivo
     * copiado com sucesso depois que o stream de escrita FECHA sem erro -- em drives instáveis
     * (ex: HD sem energia suficiente via OTG), a escrita em si pode "terminar" mas o fechamento
     * (que finaliza a cadeia de clusters no FAT) falhar depois, e sem essa checagem a barra de
     * progresso mostrava 100% mesmo quando o arquivo não ficou gravado corretamente no drive.
     */
    private ResultadoCopia executarTarefas(UsbFile destRootInicial, List<CopyTask> tarefas, String nomeParaNotificacao, Map<String, UsbFile> dirCache) {
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(10 * 60 * 1000L /*10 min, com timeout de segurança*/); } catch (Exception ignored) {}
        }

        iniciarNotificacao(nomeParaNotificacao);
        postFileCount(0, totalArquivos);

        ResultadoCopia resultado = new ResultadoCopia();
        resultado.sucesso = true;
        UsbFile destRoot = destRootInicial;

        for (CopyTask task : tarefas) {
            boolean sucessoTask = false;
            Exception ultimaExcecao = null;

            for (int tentativa = 1; tentativa <= MAX_TENTATIVAS && !sucessoTask; tentativa++) {
                try {
                    if (task.localFile.isDirectory()) {
                        resolverOuCriarDir(destRoot, task.destPath, dirCache);
                    } else {
                        copiarArquivo(destRoot, task, dirCache);
                        arquivosCopiados++;
                        postFileCount(arquivosCopiados, totalArquivos);
                    }
                    sucessoTask = true;
                } catch (Exception e) {
                    ultimaExcecao = e;
                    e.printStackTrace();

                    // Remove o arquivo parcialmente escrito antes de tentar de novo -- um write
                    // que falhou pode deixar a cadeia de clusters em estado inconsistente.
                    limparArquivoParcial(destRoot, task, dirCache);

                    if (tentativa < MAX_TENTATIVAS) {
                        postStatus(getString(R.string.status_erro_tentando_novamente_fmt, tentativa, MAX_TENTATIVAS));
                        // Backoff crescente: dá mais tempo pra uma ponte USB-SATA/pendrive instável
                        // "respirar" entre tentativas, em vez de martelar o dispositivo.
                        try { Thread.sleep(2000L * tentativa); } catch (InterruptedException ignored) {}

                        // Se o drive caiu do barramento e voltou no meio da transferência (comum
                        // com cabo/porta OTG instável), a conexão antiga fica com referências
                        // mortas -- insistir nela nunca funciona mesmo com o drive já de volta.
                        // Tenta reconectar do zero e, se conseguir, troca para o novo "destRoot"
                        // e descarta o cache de pastas (que aponta pra conexão antiga).
                        postStatus(getString(R.string.status_verificando_conexao));
                        if (UsbXboxConnection.getInstance().reconectarSeNecessario(TransferService.this)) {
                            UsbFile novaRaiz = UsbXboxConnection.getInstance().getFileSystem().getRootDirectory();
                            if (novaRaiz != null) {
                                destRoot = novaRaiz;
                                dirCache.clear();
                            }
                        }
                    }
                }
            }

            if (!sucessoTask) {
                resultado.sucesso = false;
                resultado.erro = ultimaExcecao != null ? String.valueOf(ultimaExcecao.getMessage()) : "Erro desconhecido";
                break;
            }
        }

        return resultado;
    }

    private void limparArquivoParcial(UsbFile destRoot, CopyTask task, Map<String, UsbFile> dirCache) {
        if (task.localFile.isDirectory()) return;
        try {
            String[] parentSegments = Arrays.copyOf(task.destPath, task.destPath.length - 1);
            String fileName = task.destPath[task.destPath.length - 1];
            UsbFile parentDir = resolverOuCriarDir(destRoot, parentSegments, dirCache);
            UsbFile parcial = findChild(parentDir, fileName, false);
            if (parcial != null) parcial.delete();
        } catch (Exception ignored) {
            // Melhor esforço -- se não conseguir limpar, a próxima tentativa ainda vai
            // detectar o arquivo (tamanho errado) e sobrescrever normalmente.
        }
    }

    private void pararServico() {
        stopForeground(STOP_FOREGROUND_DETACH);
        stopSelf();
    }

    private void mapearRecursivoXEX(DocumentFile dir, String[] basePath, List<CopyTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;
        for (DocumentFile f : files) {
            String[] currentPath = appendPath(basePath, f.getName());
            tarefas.add(new CopyTask(f, currentPath));
            if (f.isDirectory()) {
                mapearRecursivoXEX(f, currentPath, tarefas);
            } else {
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private void analisarPastaSTFS(DocumentFile dir, String defaultFolderName, List<CopyTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;

        String[] godPathDaPastaAtual = null;
        boolean infosDoJogoJaExibidas = (lastGameName != null);

        for (DocumentFile f : files) {
            if (f.isFile()) {
                String[] info = readSTFSHeader(f);
                if (info != null) {
                    if (!infosDoJogoJaExibidas) {
                        postGameInfo(GameDatabase.getNomeDoJogo(info[0]), info[0]);
                        infosDoJogoJaExibidas = true;
                    }
                    if (info[1].equals("00007000")) {
                        godPathDaPastaAtual = new String[]{"Content", "0000000000000000", info[0], "00007000"};
                        break;
                    }
                }
            }
        }

        for (DocumentFile f : files) {
            if (f.isDirectory()) {
                if (f.getName() != null && f.getName().endsWith(".data") && godPathDaPastaAtual != null) {
                    mapearRecursivoSTFS(f, appendPath(godPathDaPastaAtual, f.getName()), tarefas);
                } else {
                    analisarPastaSTFS(f, defaultFolderName + "/" + f.getName(), tarefas);
                }
            } else {
                String[] info = readSTFSHeader(f);
                String[] destPath;
                if (info != null) {
                    destPath = new String[]{"Content", "0000000000000000", info[0], info[1], f.getName()};
                } else {
                    destPath = ("Games/" + defaultFolderName + "/" + f.getName()).split("/");
                }
                tarefas.add(new CopyTask(f, destPath));
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private void mapearRecursivoSTFS(DocumentFile dir, String[] destPath, List<CopyTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;
        for (DocumentFile f : files) {
            String[] currentPath = appendPath(destPath, f.getName());
            if (f.isDirectory()) {
                mapearRecursivoSTFS(f, currentPath, tarefas);
            } else {
                tarefas.add(new CopyTask(f, currentPath));
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private String[] readSTFSHeader(DocumentFile file) {
        try (InputStream is = getContentResolver().openInputStream(file.getUri())) {
            if (is == null) return null;
            byte[] h = new byte[0x364];
            if (is.read(h) >= 0x364) {
                String magic = new String(h, 0, 4);
                if (magic.equals("CON ") || magic.equals("PIRS") || magic.equals("LIVE")) {
                    return new String[]{ bytesToHex(Arrays.copyOfRange(h, 0x360, 0x364)),
                                         bytesToHex(Arrays.copyOfRange(h, 0x344, 0x348)) };
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static String bytesToHex(byte[] bytes) {
        char[] hexArray = "0123456789ABCDEF".toCharArray();
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private String[] appendPath(String[] base, String extra) {
        String[] novo = Arrays.copyOf(base, base.length + 1);
        novo[base.length] = extra;
        return novo;
    }

    /**
     * Resolve (ou cria) a cadeia de pastas indicada em "segments" dentro de destRoot,
     * usando um cache para não precisar listar o drive inteiro de novo a cada arquivo.
     */
    private UsbFile resolverOuCriarDir(UsbFile destRoot, String[] segments, Map<String, UsbFile> cache) throws IOException {
        UsbFile current = destRoot;
        StringBuilder key = new StringBuilder();
        for (String seg : segments) {
            key.append('/').append(seg);
            String k = key.toString();
            UsbFile cached = cache.get(k);
            if (cached != null) { current = cached; continue; }

            UsbFile found = findChild(current, seg, true);
            if (found == null) found = current.createDirectory(seg);
            if (found == null) throw new IOException(getString(R.string.erro_criar_pasta_fmt, seg));

            cache.put(k, found);
            current = found;
        }
        return current;
    }

    /** Procura um filho (arquivo ou pasta) pelo nome, sem diferenciar maiúsculas/minúsculas. */
    private UsbFile findChild(UsbFile parent, String name, boolean apenasPastas) throws IOException {
        UsbFile[] children = parent.listFiles();
        if (children == null) return null;
        for (UsbFile c : children) {
            boolean tipoCerto = apenasPastas ? c.isDirectory() : !c.isDirectory();
            if (tipoCerto && name.equalsIgnoreCase(c.getName())) return c;
        }
        return null;
    }

    private void copiarArquivo(UsbFile destRoot, CopyTask task, Map<String, UsbFile> dirCache) throws IOException {
        String[] parentSegments = Arrays.copyOf(task.destPath, task.destPath.length - 1);
        String fileName = task.destPath[task.destPath.length - 1];
        UsbFile parentDir = resolverOuCriarDir(destRoot, parentSegments, dirCache);

        long localSize = task.localFile.length();

        UsbFile existente = findChild(parentDir, fileName, false);
        if (existente != null) {
            if (existente.getLength() == localSize) {
                bytesCopiadosGlobal += localSize;
                atualizarUI(localSize, localSize, bytesCopiadosGlobal);
                postStatus(getString(R.string.status_verificado_ok_fmt, fileName));
                return;
            }
            postStatus(getString(R.string.status_substituindo_fmt, fileName));
            existente.delete();
        }

        postStatus(getString(R.string.status_copiando_fmt, fileName));
        UsbFile novoArquivo = parentDir.createFile(fileName);

        // Reserva o espaço de uma vez (contíguo quando possível), em vez de crescer a cadeia
        // de clusters a cada write() -- muito mais rápido em drives grandes (recomendação da libaums).
        try {
            novoArquivo.setLength(localSize);
        } catch (Exception ignored) {}

        // IMPORTANTE: "bytesCopiadosGlobal += localSize" só acontece DEPOIS deste bloco todo,
        // incluindo o close() implícito do try-with-resources. Se o close() falhar (ex: drive
        // instável durante a finalização da cadeia de clusters), a exceção sobe e o arquivo
        // NÃO é contado como copiado -- antes esse incremento estava dentro do bloco e podia
        // "declarar sucesso" um arquivo que na verdade falhou ao fechar.
        try (InputStream is = getContentResolver().openInputStream(task.localFile.getUri());
             UsbFileOutputStream os = new UsbFileOutputStream(novoArquivo)) {
            if (is == null) throw new IOException(getString(R.string.erro_ler_arquivo_local_fmt, fileName));

            byte[] buffer = new byte[BUFFER_SIZE];
            long copiados = 0;
            int lidos;
            while ((lidos = is.read(buffer)) != -1) {
                os.write(buffer, 0, lidos);
                copiados += lidos;
                atualizarUI(copiados, localSize, bytesCopiadosGlobal + copiados);
            }
        }
        bytesCopiadosGlobal += localSize;
    }

    private long ultimoNotifyMs = 0;
    private int ultimoPctNotificado = -1;

    private void atualizarUI(long bytesArquivoAtual, long tamanhoTotalArquivoLocal, long totalBytesCopiadosAteMomento) {
        int pI = tamanhoTotalArquivoLocal > 0 ? (int) ((bytesArquivoAtual * 100) / tamanhoTotalArquivoLocal) : 0;
        int pT = totalBytesGlobal > 0 ? (int) ((totalBytesCopiadosAteMomento * 100) / totalBytesGlobal) : 0;

        if (pI > 100) pI = 100;
        if (pT > 100) pT = 100;

        postProgress(pI, pT);

        long agora = System.currentTimeMillis();
        boolean percentualMudou = pT != ultimoPctNotificado;
        boolean passouTempoMinimo = (agora - ultimoNotifyMs) >= 400;

        if (notificationBuilder != null && notificationManager != null && percentualMudou && passouTempoMinimo) {
            ultimoNotifyMs = agora;
            ultimoPctNotificado = pT;
            notificationBuilder.setProgress(100, pT, false)
                    .setContentText(getString(R.string.notif_total_fmt, pT, arquivosCopiados, totalArquivos));
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }

    private void iniciarNotificacao(String nomeJogo) {
        ultimoNotifyMs = 0;
        ultimoPctNotificado = -1;
        notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(getString(R.string.notif_copiando_fmt, nomeJogo))
                .setContentText(getString(R.string.notif_calculando_tempo))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        notificationManager.notify(NOTIF_ID, notificationBuilder.build());
    }

    private void finalizarNotificacao(String nomeJogo, boolean sucesso) {
        if (notificationBuilder != null && notificationManager != null) {
            if (sucesso) {
                notificationBuilder.setContentTitle(getString(R.string.notif_transferencia_concluida_title))
                        .setContentText(getString(R.string.notif_ja_esta_no_xbox_fmt, nomeJogo))
                        .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                        .setProgress(0, 0, false)
                        .setOngoing(false);
            } else {
                notificationBuilder.setContentTitle(getString(R.string.notif_erro_title))
                        .setContentText(getString(R.string.notif_falha_enviar_fmt, nomeJogo))
                        .setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setProgress(0, 0, false)
                        .setOngoing(false);
            }
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }
}
