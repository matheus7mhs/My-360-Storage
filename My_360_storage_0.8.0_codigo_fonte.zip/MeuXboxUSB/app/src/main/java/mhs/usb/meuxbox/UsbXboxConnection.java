package mhs.usb.meuxbox;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;

import java.util.List;

import me.jahnen.libaums.core.UsbMassStorageDevice;
import me.jahnen.libaums.core.fs.FileSystem;
import me.jahnen.libaums.core.partition.Partition;

/**
 * Mantém viva a conexão com o pendrive/HD do Xbox 360 (via libaums) enquanto o app
 * estiver em uso, para que MainActivity, TransferService e MeusJogosFragment
 * compartilhem o mesmo FileSystem sem precisar reconectar a cada tela.
 *
 * Não sobrevive a um "matar o app"/reiniciar processo - nesse caso o usuário precisa
 * tocar em "Selecionar Pendrive/HD" de novo (é rápido, a permissão do Android já fica
 * concedida da vez anterior na maioria dos aparelhos).
 */
public class UsbXboxConnection {

    private static final String ACTION_USB_PERMISSION = "mhs.usb.meuxbox.USB_PERMISSION";

    private static final UsbXboxConnection INSTANCE = new UsbXboxConnection();

    public static UsbXboxConnection getInstance() {
        return INSTANCE;
    }

    public interface ConnectionCallback {
        void onConnected(String deviceLabel);
        void onError(String mensagem);
    }

    private UsbMassStorageDevice device;
    private FileSystem fileSystem;
    private String deviceLabel;
    private BroadcastReceiver receiver;

    private UsbXboxConnection() {}

    public boolean isConnected() {
        return fileSystem != null;
    }

    public FileSystem getFileSystem() {
        return fileSystem;
    }

    public String getDeviceLabel() {
        return deviceLabel;
    }

    public synchronized void disconnect() {
        if (device != null) {
            try { device.close(); } catch (Exception ignored) {}
        }
        device = null;
        fileSystem = null;
        deviceLabel = null;
    }

    private static final int MAX_TENTATIVAS_INIT = 3;

    /**
     * Deve ser chamado fora da UI thread (faz I/O). Troca a conexão ativa (se houver)
     * pela nova. Lança exceção com uma mensagem amigável em caso de falha.
     */
    public synchronized void conectar(UsbMassStorageDevice novoDevice) throws Exception {
        disconnect();

        // HDs externos (mais do que pendrives) costumam falhar na primeira tentativa de
        // init() durante o "spin-up" do disco, quando o consumo de energia momentâneo pode
        // passar do que a porta/cabo OTG consegue entregar de forma estável -- gerando
        // exatamente o erro "MAX_RECOVERY_ATTEMPTS Exceeded" na negociação SCSI inicial.
        // Como isso é frequentemente transitório, tentamos de novo algumas vezes com uma
        // pequena pausa antes de desistir, em vez de falhar na primeira tentativa.
        Exception ultimoErro = null;
        for (int tentativa = 1; tentativa <= MAX_TENTATIVAS_INIT; tentativa++) {
            try {
                novoDevice.init();
                ultimoErro = null;
                break;
            } catch (Exception e) {
                ultimoErro = e;
                if (tentativa < MAX_TENTATIVAS_INIT) {
                    try { Thread.sleep(800L * tentativa); } catch (InterruptedException ignored) {}
                }
            }
        }
        if (ultimoErro != null) throw ultimoErro;

        List<Partition> partitions = novoDevice.getPartitions();
        if (partitions == null || partitions.isEmpty()) {
            throw new Exception("Nenhuma partição encontrada neste dispositivo.");
        }

        FileSystem fs = partitions.get(0).getFileSystem();
        if (fs == null) {
            throw new Exception("Partição encontrada, mas não é FAT32 (a libaums só sabe ler FAT32).");
        }

        this.device = novoDevice;
        this.fileSystem = fs;

        UsbDevice ud = novoDevice.getUsbDevice();
        String nome = null;
        try { nome = ud.getProductName(); } catch (Exception ignored) {}
        this.deviceLabel = (nome != null && !nome.trim().isEmpty()) ? nome : ud.getDeviceName();
    }

    /**
     * Atalho de conveniência: detecta o primeiro dispositivo de armazenamento USB
     * conectado, pede permissão se necessário, e finaliza a conexão sozinho. Usado
     * em telas (como "Meus Jogos") que precisam garantir uma conexão ativa sem
     * duplicar o fluxo manual de permissão que a MainActivity já implementa.
     */
    public void connectAuto(Context context, ConnectionCallback callback) {
        Context appContext = context.getApplicationContext();
        UsbManager usbManager = (UsbManager) appContext.getSystemService(Context.USB_SERVICE);

        UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(context);
        if (devices == null || devices.length == 0) {
            callback.onError(appContext.getString(R.string.toast_nenhum_usb_detectado));
            return;
        }

        UsbMassStorageDevice escolhido = devices[0];
        UsbDevice usbDevice = escolhido.getUsbDevice();

        if (usbManager.hasPermission(usbDevice)) {
            finalizarEmBackground(appContext, escolhido, callback);
            return;
        }

        if (receiver != null) {
            try { appContext.unregisterReceiver(receiver); } catch (Exception ignored) {}
        }

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                try { appContext.unregisterReceiver(receiver); } catch (Exception ignored) {}
                receiver = null;
                if (granted) {
                    finalizarEmBackground(appContext, escolhido, callback);
                } else {
                    callback.onError(appContext.getString(R.string.toast_permissao_usb_negada));
                }
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            appContext.registerReceiver(receiver, filter);
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent permissionIntent = PendingIntent.getBroadcast(appContext, 0, new Intent(ACTION_USB_PERMISSION), flags);
        usbManager.requestPermission(usbDevice, permissionIntent);
    }

    private void finalizarEmBackground(Context appContext, UsbMassStorageDevice escolhido, ConnectionCallback callback) {
        new Thread(() -> {
            try {
                conectar(escolhido);
                callback.onConnected(deviceLabel);
            } catch (Exception e) {
                callback.onError(appContext.getString(R.string.toast_erro_conectar_destino_fmt, String.valueOf(e.getMessage())));
            }
        }).start();
    }

    /**
     * Tenta reconectar ao mesmo dispositivo (primeiro storage USB encontrado) do zero.
     * Usado quando uma operação falha com erro de I/O em condições que sugerem que o
     * drive foi desconectado/reconectado fisicamente no meio da transferência (cabo/porta
     * OTG instável) -- nesse caso a conexão antiga fica com referências mortas, e insistir
     * nela nunca funciona, mesmo que o drive já esteja de volta no barramento USB.
     *
     * Deve ser chamado fora da UI thread. Retorna true se conseguiu reconectar.
     */
    public boolean reconectarSeNecessario(Context context) {
        try {
            UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(context);
            if (devices == null || devices.length == 0) return false;
            conectar(devices[0]);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Resolve um caminho relativo (ex: "Content/0000000000000000/584108A4/00000002") a partir
     * da raiz do drive, navegando pasta por pasta. Retorna null se algum trecho não existir.
     * Deve ser chamado fora da UI thread.
     */
    public me.jahnen.libaums.core.fs.UsbFile resolverCaminho(String caminhoRelativo) throws java.io.IOException {
        if (fileSystem == null) return null;
        me.jahnen.libaums.core.fs.UsbFile atual = fileSystem.getRootDirectory();
        if (caminhoRelativo == null || caminhoRelativo.trim().isEmpty()) return atual;

        for (String seg : caminhoRelativo.split("/")) {
            if (seg.isEmpty()) continue;
            me.jahnen.libaums.core.fs.UsbFile[] filhos = atual.listFiles();
            me.jahnen.libaums.core.fs.UsbFile encontrado = null;
            if (filhos != null) {
                for (me.jahnen.libaums.core.fs.UsbFile f : filhos) {
                    if (seg.equalsIgnoreCase(f.getName())) { encontrado = f; break; }
                }
            }
            if (encontrado == null) return null;
            atual = encontrado;
        }
        return atual;
    }

    /**
     * Apaga um arquivo ou pasta (recursivamente, se for pasta) do drive do Xbox.
     * Deve ser chamado fora da UI thread. É destrutivo e não tem "lixeira" -- o chamador
     * é responsável por confirmar com o usuário antes de invocar isso.
     */
    public static void deletarRecursivo(me.jahnen.libaums.core.fs.UsbFile arquivo) throws java.io.IOException {
        if (arquivo == null) return;
        if (arquivo.isDirectory()) {
            me.jahnen.libaums.core.fs.UsbFile[] filhos = arquivo.listFiles();
            if (filhos != null) {
                for (me.jahnen.libaums.core.fs.UsbFile f : filhos) {
                    deletarRecursivo(f);
                }
            }
        }
        arquivo.delete();
    }
}
